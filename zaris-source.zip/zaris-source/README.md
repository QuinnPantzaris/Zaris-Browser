# Zaris — desktop app (v0.8.0)

## What's new in v0.8.0

- **Downloads now pop up a toast notification**, bottom-left of the window
  (same convention as Chrome/Firefox), the moment a download starts —
  filename, live progress bar, percentage and size while it's running, then
  a checkmark and "click to show in folder" once it's done. No need to open
  the Library panel just to know something downloaded. Multiple downloads
  stack as separate cards. Auto-dismisses ~6 seconds after finishing, pauses
  that timer while your mouse is over it, and has its own × to dismiss
  early. Failed/cancelled downloads get their own red-tinted state instead
  of silently vanishing.

# Zaris — desktop app (v0.7.1)

## What's new in v0.7.1

- **Fixed the "buttons barely clickable" bug** in the Library panel (and,
  pre-emptively, the find bar, tab context menu, address-bar suggestions,
  and the save-password banner). Root cause: the frameless-window rework
  a couple rounds back marked the title bar/tab strip/toolbar as OS-level
  drag regions, but Chromium's drag-region hit-testing doesn't reliably
  defer to other elements floating on top just because they're visually
  layered above it with a higher `z-index` — the Library panel's top edge
  overlaps the same screen coordinates as the draggable title bar
  underneath it, so clicks there were intermittently being swallowed as
  "start dragging the window" instead of reaching the button underneath.
  Every floating panel now explicitly declares
  `-webkit-app-region: no-drag`, the standard fix for this class of bug in
  frameless Electron apps.

# Zaris — desktop app (v0.7.0)

## What's new in v0.7.0

- **Publisher name set to Quinn Pantzaris.** This wasn't just a label
  somewhere in the installer — it's now baked into the actual compiled
  `.exe`'s Windows version-info resource (`CompanyName` and
  `LegalCopyright` fields), verified directly against the built binary.
  That's what Windows reads for the "Publisher" column in Add/Remove
  Programs, the file's Properties → Details tab, and any UAC prompt.
- **A real installer wizard**, not just a bare directory-picker:
  - A license page, reading from the new `LICENSE.txt` (MIT, © 2026 Quinn
    Pantzaris — a real, permissive license now backs the project, not the
    placeholder "UNLICENSED" it had before)
  - Desktop and Start Menu shortcuts created automatically
  - Installed directly into the Start Menu root rather than a vendor
    subfolder, since it's a single app
  - "Launch Zaris" runs automatically when setup finishes
  - The installer/uninstaller windows now show the Zaris icon instead of a
    generic one
- Uninstalling does **not** wipe your saved bookmarks/history/passwords —
  that's a deliberate choice (a browser silently deleting your data on
  uninstall would be a bad surprise), not an oversight. If you'd rather
  uninstalls be a clean slate, `"deleteAppDataOnUninstall": true` in the
  `nsis` block of `package.json` is one line.

## What's new in v0.6.0

- **Frameless window — no more mismatched title bar.** The window was
  `frame: true` (Electron's default) this whole time, which draws Windows'
  own native title bar above all of Zaris's own dark UI — that's the "not
  together" seam. Zaris is now fully frameless (`frame: false`); a custom
  title-bar strip (`#titlebar` in `index.html`/`styles.css`) is the entire
  top edge instead, with hand-built minimize/maximize/close buttons wired up
  through `main.js` (there's no native title bar left to provide them).
  Double-clicking the strip maximizes/restores, same as any normal window.
- **Tabs shrink to fit instead of running off-screen.** Previously each tab
  had a fixed 120–200px width and the strip just scrolled once they
  overflowed. Now `resizeTabs()` in `renderer.js` recalculates every open
  (unpinned) tab's width to fit the available strip width, shrinking them
  down to a 44px floor as you open more — exactly how Chrome/Firefox behave.
  Only past that floor does it fall back to horizontal scrolling.
- **Ad/tracker blocking: kept, but explained — and the YouTube gap addressed.**
  On "since we use Brave, do we still need this": Brave Search (the results
  page) and ad/tracker blocking are two unrelated things — the blocker's job
  is filtering ads/trackers on every site you visit, not just search
  results, so dropping it would mean full exposure everywhere else (news
  sites, shopping, blogs — the exact "bloatware" this project started out
  avoiding). Kept it as-is for that reason.
  On YouTube specifically: correct, and there's a real reason for it —
  EasyList/EasyPrivacy only block ads by *network request*, but YouTube
  serves its ads through the same first-party pipeline as the actual video,
  so a request-blocking-only list structurally can't tell them apart.
  Actually blocking YouTube ads needs uBlock Origin's own extended-syntax
  filters (rules that target the YouTube player's internals directly, not
  just its network calls) — added three of uBlock's own lists (`filters`,
  `quick-fixes`, `unbreak`) alongside EasyList to cover this. One honest
  caveat: Zaris fetches all filter lists once at launch, not continuously in
  the background like a real extension would, so YouTube's frequent
  countermeasure changes may take until your next restart to catch up.

## What's new in v0.5.0

- **Session restore.** Closing Zaris and reopening it brings back exactly
  the tabs you had open — same URLs, same pin state, same active tab. Saved
  to disk on every tab change (debounced) and flushed immediately on quit,
  so a normal close never loses anything. One real limitation: a restored
  tab gets its last URL back, not its own back/forward history — that part
  of a "real" session restore is a bigger feature for later if it matters.
- **Crash recovery per tab.** If a single tab's page process dies (heavy
  page, memory pressure, whatever) it now shows the same Zaris-styled error
  page as a failed load, instead of just sitting there frozen forever.
- **Password autofill**, built from scratch since Electron doesn't ship
  Chromium's actual password manager component:
  - Every tab gets its own preload script (`webview-preload.js`) that
    detects a login form on submit and reports it to the main process
    without exposing anything to the page itself
  - A small banner then offers to save it — Save / Never for this site /
    Not now
  - Saved passwords are encrypted at rest via Electron's `safeStorage`,
    which hands off to the OS's own credential store (Windows DPAPI /
    macOS Keychain / libsecret on Linux) — not sitting in the JSON file as
    plain text
  - On revisiting a site with exactly one saved login, it autofills (skipped
    if there are 2+ saved logins for that site, since guessing which one is
    worse than just asking you to pick)
  - A new "Passwords" tab in the Library panel lists saved site+username
    pairs — the password itself is never displayed there, only removable
  - Honest scope note: this is a first-pass implementation, not a
    full-featured password manager — no password generation, no breach
    checking, no import/export yet.
- **PDFs now open inline** in a tab instead of forcing a download every
  time (Chromium's built-in PDF viewer, `plugins=yes` on each webview).

## What's new in v0.4.0

- **Search prediction / autocomplete.** Type in the address bar and a
  dropdown appears with: matching bookmarks and history entries first
  (yours, so they're weighted above generic predictions), then live search
  predictions from Brave's public suggest endpoint — the same one Brave
  documents for other browsers to use, no API key needed. Arrow keys to
  navigate, `Enter` to go, `Esc` to dismiss, click also works.
- **Spell check.** Chromium's built-in spellchecker is now explicitly
  enabled (`en-US`) — misspelled words get underlined in any text field on
  any page, and right-clicking one shows real suggestions plus
  "Add to Dictionary," same as any mainstream browser.

## What's new in v0.3.1

- **Brave Search's own logo/branding is now hidden.** It's a link in their
  header pointing to brave.com (their browser's download page) — Zaris now
  detects and hides any header-area link pointing there, regardless of
  Brave's current CSS class names, since those change on redesigns but the
  link's actual destination doesn't. This is the first entry in a small
  "site quirks" system (`SITE_QUIRKS` in `main.js`) — add another hostname
  there with its own cleanup script to fix similar annoyances on other sites
  later.
- One honest caveat: this was built without being able to visually load the
  real page from this environment, so it's a best-effort match rather than
  a visually-confirmed one. If any sliver of it is still visible, say so and
  the matching rule can be tightened.

## What's new in v0.3.0

- **Bookmarks.** Star icon lives inside the address bar — click it to save
  the current page, click again to un-save. Saved pages show up in the new
  Library panel.
- **History.** Every real page visit (not the home page, not error pages)
  gets logged with title, URL, and time. Searchable by scrolling in the
  Library panel, removable one at a time or all at once.
- **Downloads list.** Anything you download now shows up with live
  progress, file size, and state (in-progress / done / failed). Click a
  finished download to reveal it in your file manager.
- **Find-in-page** — `Ctrl+F` opens a small floating bar, shows a live
  match count, `Enter`/`Shift+Enter` step through matches, `Esc` closes it.
- **Reopen closed tab** — `Ctrl+Shift+T` brings back the last tab you
  closed (re-navigates to its last URL and restores its pinned state;
  it doesn't restore that tab's own back/forward history — a real
  "session history" restore is a bigger feature for later if you want it).
- **Everything above persists across restarts.** Bookmarks, history, and
  the downloads list are written to a small JSON file in Zaris's own app
  data folder — closing and reopening the browser doesn't lose any of it.
  (Windows: `%APPDATA%\Zaris\zaris-data.json`.)

New shortcuts: `Ctrl+D` bookmark the page, `Ctrl+J` open the downloads
list, `Ctrl+Shift+T` reopen last closed tab, `Ctrl+F` find in page.

## Everything from earlier rounds is still in

- Home button (`Alt+Home`), auto-retry on failed loads, Brave Search as the
  default engine, force-dark rendering, native right-click menus, tab
  drag-reorder/pin/duplicate/close-others, EasyList/EasyPrivacy ad
  blocking, clean launch/tab/panel animations, readable sans-serif chrome
  font with Spartacus reserved for the wordmark.

## Still on the "not done yet" list

- The shield (adblock toggle) button is cosmetic — flips its icon but
  doesn't call back into the main process to actually disable filtering
  live yet
- No per-site dark-mode override
- Reopened tabs don't restore their own back/forward history, just their
  last URL
- No zoom controls yet

## Running it

Two prebuilt files sit next to this README:
- **`Zaris-portable.exe`** — no install, just run it
- **`Zaris-Setup.exe`** — proper installer with uninstaller

Windows SmartScreen may flag both on first run since there's no paid code
signing certificate attached — click "More info" → "Run anyway." First
launch needs a moment of internet access to fetch the ad/tracker filter
lists; after that they're cached.

## Rebuilding it yourself

```
npm install
npm start          # run it live
npm run dist:win   # -> dist/Zaris-Setup-*.exe and dist/Zaris-*-portable.exe
```

On Linux, building a Windows target needs Wine
(`sudo dpkg --add-architecture i386 && sudo apt update && sudo apt install wine32:i386 wine64`)
so electron-builder can stamp the exe's icon/metadata. Or push this repo to
GitHub — `.github/workflows/build.yml` is already wired up to build it on
`windows-latest` and hand you the `.exe` as an Actions artifact, no local
setup at all.
