const { contextBridge, ipcRenderer } = require("electron");
const path = require("path");

const errorPagePath = "file://" + path.join(__dirname, "error.html").replace(/\\/g, "/");
const homePagePath = "file://" + path.join(__dirname, "startpage.html").replace(/\\/g, "/");
const webviewPreloadPath = "file://" + path.join(__dirname, "webview-preload.js").replace(/\\/g, "/");

contextBridge.exposeInMainWorld("zaris", {
  platform: process.platform,
  openExternal: (url) => ipcRenderer.invoke("open-external", url),
  onOpenTab: (callback) => ipcRenderer.on("open-tab", (_e, url) => callback(url)),
  // A resolved, absolute file:// URL — a webview created and given a src
  // before it's ever been attached to the DOM can't reliably resolve a bare
  // relative path like "startpage.html" against the host window's location,
  // especially once the app is packaged. This is what was causing the home
  // page to fail to load right at launch.
  homePage: () => homePagePath,
  suggest: (query) => ipcRenderer.invoke("suggest", query),
  // A file:// path handed to a <webview>'s own "preload" attribute — this is
  // what gives every tab login-detection/autofill, entirely separate from
  // the host window's own preload above.
  webviewPreload: () => webviewPreloadPath,
  // Builds (or, called with "", returns the base of) the local error page URL
  // so the renderer never has to hardcode a filesystem path itself.
  errorPage: (params) => {
    if (!params) return errorPagePath;
    const qs = new URLSearchParams(params).toString();
    return errorPagePath + (qs ? "?" + qs : "");
  },

  // ---- persistent data: bookmarks, history, downloads --------------------
  data: {
    get: () => ipcRenderer.invoke("data:get"),
    addBookmark: (title, url) => ipcRenderer.invoke("data:addBookmark", { title, url }),
    removeBookmark: (id) => ipcRenderer.invoke("data:removeBookmark", id),
    isBookmarked: (url) => ipcRenderer.invoke("data:isBookmarked", url),
    addHistory: (title, url) => ipcRenderer.invoke("data:addHistory", { title, url }),
    removeHistoryEntry: (id) => ipcRenderer.invoke("data:removeHistoryEntry", id),
    clearHistory: () => ipcRenderer.invoke("data:clearHistory"),
    clearDownloads: () => ipcRenderer.invoke("data:clearDownloads"),
    showItemInFolder: (path_) => ipcRenderer.invoke("data:showItemInFolder", path_),
    openPath: (path_) => ipcRenderer.invoke("data:openPath", path_),
    onDownloadUpdate: (callback) => ipcRenderer.on("download-update", (_e, record) => callback(record)),
  },

  // ---- session restore ---------------------------------------------------
  session: {
    get: () => ipcRenderer.invoke("session:get"),
    save: (sessionData) => ipcRenderer.invoke("session:save", sessionData),
  },

  // ---- saved passwords ----------------------------------------------------
  creds: {
    save: (hostname, username, password) => ipcRenderer.invoke("creds:save", { hostname, username, password }),
    list: () => ipcRenderer.invoke("creds:list"),
    remove: (id) => ipcRenderer.invoke("creds:remove", id),
    onOfferSave: (callback) => ipcRenderer.on("creds:offer-save", (_e, data) => callback(data)),
  },

  // ---- custom title-bar window controls (frameless window) ---------------
  window: {
    minimize: () => ipcRenderer.send("window:minimize"),
    maximize: () => ipcRenderer.send("window:maximize"),
    close: () => ipcRenderer.send("window:close"),
    isMaximized: () => ipcRenderer.invoke("window:isMaximized"),
    onMaximizedChange: (callback) => ipcRenderer.on("window:maximized", (_e, isMax) => callback(isMax)),
  },
});
