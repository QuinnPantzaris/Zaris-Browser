const webviewsEl = document.getElementById("webviews");
const tabstripEl = document.getElementById("tabstrip");
const urlbar = document.getElementById("urlbar");
const btnBack = document.getElementById("btn-back");
const btnFwd = document.getElementById("btn-fwd");
const btnReload = document.getElementById("btn-reload");
const btnHome = document.getElementById("btn-home");
const btnNewtab = document.getElementById("btn-newtab");
const btnShield = document.getElementById("btn-shield");
const btnStar = document.getElementById("btn-star");
const btnLibrary = document.getElementById("btn-library");

const findbar = document.getElementById("findbar");
const findInput = document.getElementById("find-input");
const findCount = document.getElementById("find-count");

const libraryOverlay = document.getElementById("library-overlay");
const libraryPanel = document.getElementById("library-panel");

// Resolved once, up front, to an absolute file:// URL — see the comment on
// homePage() in preload.js for why this can't just be the bare string
// "startpage.html" anymore.
const START_URL = window.zaris.homePage();
// Brave Search instead of DuckDuckGo's bare /html/ endpoint: real dark theme,
// actual image results, still a privacy-respecting independent index.
const SEARCH_URL = "https://search.brave.com/search?q=";

const MAX_AUTO_RETRIES = 2;
const RETRY_DELAY_MS = 500;

let tabs = [];      // { id, webview, tabEl, title, url }
let activeId = null;
let nextId = 1;
let blockingEnabled = true; // cosmetic toggle; actual filtering lives in main.js session
let closedTabs = []; // stack of { url, pinned } for Ctrl+Shift+T

function looksLikeUrl(raw) {
  return /^[a-zA-Z]+:\/\//.test(raw) || (/^[\w-]+(\.[\w-]+)+(\/.*)?$/.test(raw) && !raw.includes(" "));
}

function normalize(raw) {
  raw = raw.trim();
  if (!raw) return START_URL;
  if (raw === "zaris://home" || raw === "zaris:home") return START_URL;
  // Never let the address bar execute script/data URIs — typing or pasting
  // one of these should search for it as text, not run it.
  if (/^\s*(javascript|data|vbscript):/i.test(raw)) return SEARCH_URL + encodeURIComponent(raw);
  if (looksLikeUrl(raw)) return raw.startsWith("http") || raw.startsWith("file") ? raw : "https://" + raw;
  return SEARCH_URL + encodeURIComponent(raw);
}

function isInternalUrl(url) {
  return url === START_URL || url.endsWith("startpage.html") || url.includes("error.html");
}

const historyTimers = new Map();
function scheduleHistoryRecord(tab) {
  if (isInternalUrl(tab.url)) return;
  clearTimeout(historyTimers.get(tab.id));
  // Wait a beat so page-title-updated has a chance to fire first — recording
  // "New tab" as the title for every visit isn't useful.
  historyTimers.set(
    tab.id,
    setTimeout(() => {
      window.zaris.data.addHistory(tab.title, tab.url);
      historyTimers.delete(tab.id);
    }, 700)
  );
}

let sessionSaveTimer = null;
function scheduleSessionSave() {
  clearTimeout(sessionSaveTimer);
  sessionSaveTimer = setTimeout(() => {
    const snapshot = {
      activeIndex: tabs.findIndex((t) => t.id === activeId),
      tabs: tabs.map((t) => ({
        url: isInternalUrl(t.url) ? "zaris://home" : t.url,
        pinned: t.pinned,
      })),
    };
    window.zaris.session.save(snapshot);
  }, 400);
}

function createTab(url) {
  const id = nextId++;

  const webview = document.createElement("webview");
  webview.setAttribute("allowpopups", "true");
  // plugins=yes turns on Chromium's built-in PDF viewer (open a PDF in a tab
  // instead of it just forcing a download); sandbox=no lets the preload
  // below use ipcRenderer for autofill.
  webview.setAttribute("webpreferences", "spellcheck=yes,plugins=yes,sandbox=no");
  webview.setAttribute("preload", window.zaris.webviewPreload());
  webview.src = url || START_URL;
  webviewsEl.appendChild(webview);

  const tabEl = document.createElement("div");
  tabEl.className = "tab";
  tabEl.innerHTML = `<span class="title">New tab</span><span class="close">&times;</span>`;
  tabEl.addEventListener("click", (e) => {
    if (e.target.classList.contains("close")) {
      closeTab(id);
    } else {
      activateTab(id);
    }
  });
  tabstripEl.appendChild(tabEl);

  const tab = { id, webview, tabEl, title: "New tab", url: webview.src, pinned: false, retryCount: 0 };
  tabs.push(tab);

  // ---- drag-to-reorder -----------------------------------------------
  tabEl.draggable = true;
  tabEl.addEventListener("dragstart", (e) => {
    e.dataTransfer.setData("text/zaris-tab-id", String(id));
    e.dataTransfer.effectAllowed = "move";
    requestAnimationFrame(() => tabEl.classList.add("dragging"));
  });
  tabEl.addEventListener("dragend", () => tabEl.classList.remove("dragging"));
  tabEl.addEventListener("dragover", (e) => {
    e.preventDefault();
    const rect = tabEl.getBoundingClientRect();
    const before = e.clientX - rect.left < rect.width / 2;
    tabEl.classList.toggle("drag-over-left", before);
    tabEl.classList.toggle("drag-over-right", !before);
  });
  tabEl.addEventListener("dragleave", () => {
    tabEl.classList.remove("drag-over-left", "drag-over-right");
  });
  tabEl.addEventListener("drop", (e) => {
    e.preventDefault();
    tabEl.classList.remove("drag-over-left", "drag-over-right");
    const draggedId = Number(e.dataTransfer.getData("text/zaris-tab-id"));
    if (draggedId === id) return;
    const rect = tabEl.getBoundingClientRect();
    const before = e.clientX - rect.left < rect.width / 2;
    reorderTab(draggedId, id, before);
  });

  // ---- right-click: tab organization menu -----------------------------
  tabEl.addEventListener("contextmenu", (e) => {
    e.preventDefault();
    showTabMenu(e.clientX, e.clientY, tab);
  });

  webview.addEventListener("page-title-updated", (e) => {
    tab.title = e.title || tab.title;
    tabEl.querySelector(".title").textContent = tab.title;
  });
  webview.addEventListener("did-navigate", (e) => {
    tab.url = e.url;
    if (id === activeId) syncNavState();
    scheduleHistoryRecord(tab);
    scheduleSessionSave();
  });
  webview.addEventListener("did-navigate-in-page", (e) => {
    tab.url = e.url;
    if (id === activeId) syncNavState();
  });
  webview.addEventListener("found-in-page", (e) => {
    if (tab.id !== activeId) return;
    const { activeMatchOrdinal, matches } = e.result;
    findCount.textContent = matches > 0 ? `${activeMatchOrdinal}/${matches}` : "0/0";
  });

  webview.addEventListener("did-finish-load", () => {
    tab.retryCount = 0; // a real, complete load means whatever failed before is over
  });
  webview.addEventListener("did-fail-load", (e) => {
    if (!e.isMainFrame) return;               // a blocked ad iframe failing isn't "the page" failing
    if (e.errorCode === -3 || e.errorCode === 0) return; // aborted / not a real error
    if (e.validatedURL.startsWith(window.zaris.errorPage(""))) return; // don't loop on the error page itself

    // Transient failures (a page loading before the network's fully up, a
    // webview that isn't quite ready right at launch, a momentary blip)
    // deserve a couple of quiet retries before bothering you with an error
    // page — most of them resolve themselves within a few hundred ms.
    if (tab.retryCount < MAX_AUTO_RETRIES) {
      tab.retryCount++;
      setTimeout(() => {
        // Guard against retrying a tab that's since navigated elsewhere or closed.
        if (tabs.includes(tab)) webview.loadURL(e.validatedURL);
      }, RETRY_DELAY_MS);
      return;
    }

    tab.retryCount = 0;
    webview.loadURL(
      window.zaris.errorPage({
        url: e.validatedURL,
        code: String(e.errorCode),
        desc: e.errorDescription || "",
      })
    );
  });

  // A tab's own renderer process can die independently of the app itself
  // (a heavy page, a bad extension-like script, memory pressure) — without
  // this it just sits there frozen with no way back short of closing the tab.
  const handleCrash = (details) => {
    if (details && details.reason === "clean-exit") return; // a deliberate close, not a crash
    webview.loadURL(
      window.zaris.errorPage({ url: tab.url, code: "CRASHED", desc: (details && details.reason) || "" })
    );
  };
  webview.addEventListener("crashed", () => handleCrash());
  webview.addEventListener("render-process-gone", (e) => handleCrash(e.details));

  // Electron/Chromium quirk: a <webview> that's made visible for the very
  // first time right after being created sometimes doesn't paint until
  // something forces a relayout — this is why the logo didn't show up until
  // a second tab existed. Force one on first dom-ready.
  webview.addEventListener(
    "dom-ready",
    () => {
      if (tab.id !== activeId) return;
      webview.classList.remove("active");
      requestAnimationFrame(() => {
        if (tab.id === activeId) webview.classList.add("active");
      });
    },
    { once: true }
  );

  activateTab(id);
  updateTabStripVisibility();
  return tab;
}

function activateTab(id) {
  activeId = id;
  for (const t of tabs) {
    const active = t.id === id;
    t.webview.classList.toggle("active", active);
    t.tabEl.classList.toggle("active", active);
  }
  syncNavState();
  scheduleSessionSave();
}

function closeTab(id) {
  const idx = tabs.findIndex((t) => t.id === id);
  if (idx === -1) return;
  const [tab] = tabs.splice(idx, 1);

  if (!isInternalUrl(tab.url)) {
    closedTabs.push({ url: tab.url, pinned: tab.pinned });
    if (closedTabs.length > 25) closedTabs.shift();
  }

  tab.webview.remove();
  tab.tabEl.remove();

  if (tabs.length === 0) {
    createTab(START_URL);
  } else if (activeId === id) {
    const next = tabs[idx] || tabs[idx - 1] || tabs[0];
    activateTab(next.id);
  }
  updateTabStripVisibility();
  scheduleSessionSave();
}

function reopenClosedTab() {
  const last = closedTabs.pop();
  if (!last) return;
  const tab = createTab(last.url);
  if (last.pinned) togglePin(tab);
}

// ---------------------------------------------------------- organization --
function renderTabOrder() {
  // Pinned tabs always sit first, in whatever relative order they're in;
  // unpinned tabs follow. DOM order is made to match the array order.
  tabs.sort((a, b) => (b.pinned === a.pinned ? 0 : b.pinned ? 1 : -1));
  for (const t of tabs) tabstripEl.appendChild(t.tabEl);
  resizeTabs();
  scheduleSessionSave();
}

const MIN_TAB_WIDTH = 44;  // narrow enough to still show a sliver of the title + close button
const MAX_TAB_WIDTH = 200;
const PINNED_TAB_WIDTH = 40;
const TAB_GAP = 6; // matches #tabstrip's CSS gap

function resizeTabs() {
  const unpinned = tabs.filter((t) => !t.pinned);
  if (unpinned.length === 0) return;
  const pinnedCount = tabs.length - unpinned.length;

  const available = tabstripEl.clientWidth - 16 /* strip padding */ - pinnedCount * (PINNED_TAB_WIDTH + TAB_GAP);
  const widthEach = Math.max(MIN_TAB_WIDTH, Math.min(MAX_TAB_WIDTH, Math.floor(available / unpinned.length) - TAB_GAP));

  for (const t of unpinned) {
    t.tabEl.style.width = widthEach + "px";
  }
  // Below the minimum width, tabs stop shrinking further and the strip's
  // own overflow-x: auto takes over — same fallback Chrome/Firefox use once
  // a tab count gets genuinely extreme.
}

window.addEventListener("resize", resizeTabs);

function reorderTab(draggedId, targetId, before) {
  const from = tabs.findIndex((t) => t.id === draggedId);
  const to = tabs.findIndex((t) => t.id === targetId);
  if (from === -1 || to === -1) return;
  const [moved] = tabs.splice(from, 1);
  // Dragging only makes sense within the same pinned/unpinned group.
  moved.pinned = tabs[to] ? tabs[to].pinned : moved.pinned;
  const insertAt = tabs.findIndex((t) => t.id === targetId) + (before ? 0 : 1);
  tabs.splice(insertAt, 0, moved);
  renderTabOrder();
}

function togglePin(tab) {
  tab.pinned = !tab.pinned;
  tab.tabEl.classList.toggle("pinned", tab.pinned);
  renderTabOrder();
}

function duplicateTab(tab) {
  createTab(tab.url);
}

function closeOthers(tab) {
  for (const t of [...tabs]) {
    if (t.id !== tab.id) closeTab(t.id);
  }
}

function closeToRight(tab) {
  const idx = tabs.findIndex((t) => t.id === tab.id);
  for (const t of tabs.slice(idx + 1)) closeTab(t.id);
}

let openTabMenuEl = null;
function closeTabMenu() {
  if (openTabMenuEl) {
    openTabMenuEl.remove();
    openTabMenuEl = null;
  }
}

function showTabMenu(x, y, tab) {
  closeTabMenu();
  const menu = document.createElement("div");
  menu.className = "tab-menu";

  const item = (label, fn, extraClass) => {
    const el = document.createElement("div");
    el.className = "item" + (extraClass ? " " + extraClass : "");
    el.textContent = label;
    el.addEventListener("click", () => { closeTabMenu(); fn(); });
    menu.appendChild(el);
  };
  const sep = () => {
    const el = document.createElement("div");
    el.className = "sep";
    menu.appendChild(el);
  };

  item("New Tab", () => createTab(START_URL));
  item("Duplicate Tab", () => duplicateTab(tab));
  item(tab.pinned ? "Unpin Tab" : "Pin Tab", () => togglePin(tab));
  sep();
  item("Reload Tab", () => tab.webview.reload());
  sep();
  item("Close Tab", () => closeTab(tab.id), "danger");
  item("Close Other Tabs", () => closeOthers(tab), "danger");
  item("Close Tabs to the Right", () => closeToRight(tab), "danger");

  document.body.appendChild(menu);
  const rect = menu.getBoundingClientRect();
  menu.style.left = Math.min(x, window.innerWidth - rect.width - 8) + "px";
  menu.style.top = Math.min(y, window.innerHeight - rect.height - 8) + "px";
  openTabMenuEl = menu;
}

window.addEventListener("click", (e) => {
  if (openTabMenuEl && !openTabMenuEl.contains(e.target)) closeTabMenu();
});
window.addEventListener("keydown", (e) => {
  if (e.key !== "Escape") return;
  if (!findbar.classList.contains("hidden")) { closeFindBar(); return; }
  if (libraryPanel.classList.contains("visible")) { closeLibrary(); return; }
  closeTabMenu();
});

function updateTabStripVisibility() {
  const show = tabs.length > 1;
  tabstripEl.classList.toggle("hidden", !show);
  document.getElementById("webviews").style.top = show ? "118px" : "84px";
  resizeTabs();
}

function currentTab() {
  return tabs.find((t) => t.id === activeId);
}

function syncNavState() {
  const t = currentTab();
  if (!t) return;
  closeSuggestions();
  urlbar.value = (t.url === START_URL || t.url.endsWith("startpage.html")) ? "" : t.url;
  try {
    btnBack.disabled = !t.webview.canGoBack();
    btnFwd.disabled = !t.webview.canGoForward();
  } catch {
    // webview not attached to DOM yet on first tick
  }
  btnStar.style.display = isInternalUrl(t.url) ? "none" : "flex";
  if (!isInternalUrl(t.url)) {
    window.zaris.data.isBookmarked(t.url).then((yes) => {
      // Guard against the tab having changed while this promise was in flight.
      if (currentTab()?.id === t.id) btnStar.classList.toggle("active", yes);
    });
  }
}

// ------------------------------------------------------------- library ---
const libTabs = document.querySelectorAll(".lib-tab");
const libBodies = {
  bookmarks: document.getElementById("lib-bookmarks"),
  history: document.getElementById("lib-history"),
  downloads: document.getElementById("lib-downloads"),
  passwords: document.getElementById("lib-passwords"),
};

function fmtTime(ts) {
  const d = new Date(ts);
  const now = new Date();
  const sameDay = d.toDateString() === now.toDateString();
  return sameDay
    ? d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    : d.toLocaleDateString([], { month: "short", day: "numeric" }) + " · " + d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

function fmtBytes(n) {
  if (!n && n !== 0) return "";
  if (n < 1024) return n + " B";
  if (n < 1024 ** 2) return (n / 1024).toFixed(1) + " KB";
  if (n < 1024 ** 3) return (n / 1024 ** 2).toFixed(1) + " MB";
  return (n / 1024 ** 3).toFixed(2) + " GB";
}

function emptyRow(text) {
  const el = document.createElement("div");
  el.className = "lib-empty";
  el.textContent = text;
  return el;
}

async function renderBookmarks() {
  const { bookmarks } = await window.zaris.data.get();
  const body = libBodies.bookmarks;
  body.innerHTML = "";
  if (bookmarks.length === 0) {
    body.appendChild(emptyRow("No bookmarks yet — click the star in the address bar to save a page."));
    return;
  }
  for (const b of bookmarks) {
    const row = document.createElement("div");
    row.className = "lib-row";
    row.innerHTML = `
      <div class="row-main">
        <div class="row-title"></div>
        <div class="row-sub"></div>
      </div>
      <button class="row-remove" title="Remove bookmark">&times;</button>`;
    row.querySelector(".row-title").textContent = b.title;
    row.querySelector(".row-sub").textContent = b.url;
    row.addEventListener("click", (e) => {
      if (e.target.classList.contains("row-remove")) return;
      createTab(b.url);
      closeLibrary();
    });
    row.querySelector(".row-remove").addEventListener("click", async (e) => {
      e.stopPropagation();
      await window.zaris.data.removeBookmark(b.id);
      renderBookmarks();
      syncNavState();
    });
    body.appendChild(row);
  }
}

async function renderHistory() {
  const { history } = await window.zaris.data.get();
  const body = libBodies.history;
  body.innerHTML = "";

  const toolbar = document.createElement("div");
  toolbar.className = "lib-toolbar";
  const clearBtn = document.createElement("button");
  clearBtn.textContent = "Clear all history";
  clearBtn.addEventListener("click", async () => {
    await window.zaris.data.clearHistory();
    renderHistory();
  });
  toolbar.appendChild(clearBtn);
  body.appendChild(toolbar);

  if (history.length === 0) {
    body.appendChild(emptyRow("No browsing history yet."));
    return;
  }
  for (const h of history) {
    const row = document.createElement("div");
    row.className = "lib-row";
    row.innerHTML = `
      <div class="row-main">
        <div class="row-title"></div>
        <div class="row-sub"></div>
      </div>
      <button class="row-remove" title="Remove from history">&times;</button>`;
    row.querySelector(".row-title").textContent = h.title;
    row.querySelector(".row-sub").textContent = `${fmtTime(h.visitedAt)} · ${h.url}`;
    row.addEventListener("click", (e) => {
      if (e.target.classList.contains("row-remove")) return;
      createTab(h.url);
      closeLibrary();
    });
    row.querySelector(".row-remove").addEventListener("click", async (e) => {
      e.stopPropagation();
      await window.zaris.data.removeHistoryEntry(h.id);
      renderHistory();
    });
    body.appendChild(row);
  }
}

async function renderDownloads() {
  const { downloads } = await window.zaris.data.get();
  const body = libBodies.downloads;
  body.innerHTML = "";

  const toolbar = document.createElement("div");
  toolbar.className = "lib-toolbar";
  const clearBtn = document.createElement("button");
  clearBtn.textContent = "Clear finished";
  clearBtn.addEventListener("click", async () => {
    await window.zaris.data.clearDownloads();
    renderDownloads();
  });
  toolbar.appendChild(clearBtn);
  body.appendChild(toolbar);

  if (downloads.length === 0) {
    body.appendChild(emptyRow("Nothing downloaded yet."));
    return;
  }
  for (const d of downloads) {
    const pct = d.totalBytes > 0 ? Math.min(100, Math.round((d.receivedBytes / d.totalBytes) * 100)) : 0;
    const row = document.createElement("div");
    row.className = "lib-row" + (d.state === "completed" ? " download-done" : d.state === "interrupted" || d.state === "cancelled" ? " download-failed" : "");
    row.dataset.downloadId = d.id;
    row.innerHTML = `
      <div class="row-main">
        <div class="row-title"></div>
        <div class="row-sub"></div>
        ${d.state === "progressing" ? '<div class="row-progress"><div class="row-progress-fill"></div></div>' : ""}
      </div>`;
    row.querySelector(".row-title").textContent = d.filename;
    row.querySelector(".row-sub").textContent =
      d.state === "progressing" ? `${fmtBytes(d.receivedBytes)} of ${fmtBytes(d.totalBytes)}` :
      d.state === "completed" ? `${fmtBytes(d.receivedBytes)} · ${fmtTime(d.startedAt)}` :
      d.state === "cancelled" ? "Cancelled" : "Failed";
    const fill = row.querySelector(".row-progress-fill");
    if (fill) fill.style.width = pct + "%";
    row.addEventListener("click", () => {
      if (d.state === "completed") window.zaris.data.showItemInFolder(d.savePath);
    });
    body.appendChild(row);
  }
}

// ---------------------------------------------------------- download toasts
const toastContainer = document.createElement("div");
toastContainer.id = "download-toasts";
document.body.appendChild(toastContainer);

const activeToasts = new Map(); // download id -> { el, dismissTimer }
const TOAST_AUTO_DISMISS_MS = 6000;

function scheduleToastDismiss(id) {
  const entry = activeToasts.get(id);
  if (!entry) return;
  clearTimeout(entry.dismissTimer);
  entry.dismissTimer = setTimeout(() => dismissToast(id), TOAST_AUTO_DISMISS_MS);
}

function dismissToast(id) {
  const entry = activeToasts.get(id);
  if (!entry) return;
  clearTimeout(entry.dismissTimer);
  entry.el.classList.add("leaving");
  setTimeout(() => entry.el.remove(), 180);
  activeToasts.delete(id);
}

function renderToast(record) {
  let entry = activeToasts.get(record.id);
  const pct = record.totalBytes > 0 ? Math.min(100, Math.round((record.receivedBytes / record.totalBytes) * 100)) : null;
  const done = record.state !== "progressing";

  if (!entry) {
    const el = document.createElement("div");
    el.className = "download-toast";
    el.innerHTML = `
      <div class="dl-toast-icon">${done ? "\u2193" : "\u2022"}</div>
      <div class="dl-toast-main">
        <div class="dl-toast-name"></div>
        <div class="dl-toast-sub"></div>
        <div class="dl-toast-progress"><div class="dl-toast-progress-fill"></div></div>
      </div>
      <button class="dl-toast-close" title="Dismiss">&times;</button>`;
    el.querySelector(".dl-toast-close").addEventListener("click", (e) => {
      e.stopPropagation();
      dismissToast(record.id);
    });
    el.addEventListener("mouseenter", () => clearTimeout(activeToasts.get(record.id)?.dismissTimer));
    el.addEventListener("mouseleave", () => scheduleToastDismiss(record.id));
    toastContainer.prepend(el);
    entry = { el, dismissTimer: null };
    activeToasts.set(record.id, entry);
  }

  const el = entry.el;
  el.classList.toggle("done", record.state === "completed");
  el.classList.toggle("failed", record.state === "cancelled" || record.state === "interrupted");
  el.querySelector(".dl-toast-icon").textContent = record.state === "completed" ? "\u2713" : record.state === "progressing" ? "\u2193" : "\u2715";
  el.querySelector(".dl-toast-name").textContent = record.filename;
  el.querySelector(".dl-toast-sub").textContent =
    record.state === "progressing"
      ? (pct !== null ? `${pct}% · ${fmtBytes(record.receivedBytes)} of ${fmtBytes(record.totalBytes)}` : fmtBytes(record.receivedBytes))
      : record.state === "completed"
      ? `Done · ${fmtBytes(record.receivedBytes)} — click to show in folder`
      : record.state === "cancelled"
      ? "Cancelled"
      : "Failed";
  const fill = el.querySelector(".dl-toast-progress-fill");
  fill.style.width = (pct ?? (record.state === "progressing" ? 30 : 100)) + "%";
  el.querySelector(".dl-toast-progress").classList.toggle("indeterminate", record.state === "progressing" && pct === null);

  el.onclick = () => {
    if (record.state === "completed") window.zaris.data.showItemInFolder(record.savePath);
  };

  if (done) scheduleToastDismiss(record.id);
  else clearTimeout(entry.dismissTimer); // still going — don't let a stale timer kill it mid-download
}

window.zaris.data.onDownloadUpdate((record) => {
  if (libraryPanel.classList.contains("visible")) renderDownloads();
  renderToast(record);
});

async function renderPasswords() {
  const list = await window.zaris.creds.list();
  const body = libBodies.passwords;
  body.innerHTML = "";

  const note = document.createElement("div");
  note.className = "lib-toolbar";
  note.style.justifyContent = "flex-start";
  note.style.color = "var(--text-mute)";
  note.style.fontSize = "11px";
  note.style.padding = "4px 8px 10px 8px";
  note.textContent = "Passwords are encrypted on disk and never shown here — remove is the only action.";
  body.appendChild(note);

  if (list.length === 0) {
    body.appendChild(emptyRow("No saved passwords yet."));
    return;
  }
  for (const c of list) {
    const row = document.createElement("div");
    row.className = "lib-row";
    row.innerHTML = `
      <div class="row-main">
        <div class="row-title"></div>
        <div class="row-sub"></div>
      </div>
      <button class="row-remove" title="Remove saved password">&times;</button>`;
    row.querySelector(".row-title").textContent = c.hostname;
    row.querySelector(".row-sub").textContent = c.username;
    row.querySelector(".row-remove").addEventListener("click", async (e) => {
      e.stopPropagation();
      await window.zaris.creds.remove(c.id);
      renderPasswords();
    });
    body.appendChild(row);
  }
}

function switchLibTab(name) {
  for (const el of libTabs) el.classList.toggle("active", el.dataset.panel === name);
  for (const key of Object.keys(libBodies)) libBodies[key].classList.toggle("hidden", key !== name);
  if (name === "bookmarks") renderBookmarks();
  if (name === "history") renderHistory();
  if (name === "downloads") renderDownloads();
  if (name === "passwords") renderPasswords();
}

for (const el of libTabs) el.addEventListener("click", () => switchLibTab(el.dataset.panel));

function openLibrary(panel) {
  libraryOverlay.classList.remove("hidden");
  libraryPanel.classList.remove("hidden");
  requestAnimationFrame(() => {
    libraryOverlay.classList.add("visible");
    libraryPanel.classList.add("visible");
  });
  switchLibTab(panel || "bookmarks");
}

function closeLibrary() {
  libraryOverlay.classList.remove("visible");
  libraryPanel.classList.remove("visible");
  setTimeout(() => {
    libraryOverlay.classList.add("hidden");
    libraryPanel.classList.add("hidden");
  }, 220);
}

btnLibrary.addEventListener("click", () => {
  libraryPanel.classList.contains("visible") ? closeLibrary() : openLibrary("bookmarks");
});
document.getElementById("lib-close").addEventListener("click", closeLibrary);
libraryOverlay.addEventListener("click", closeLibrary);

// ------------------------------------------------------------ find bar ---
function openFindBar() {
  findbar.classList.remove("hidden");
  findInput.value = "";
  findCount.textContent = "";
  findInput.focus();
}
function closeFindBar() {
  findbar.classList.add("hidden");
  currentTab()?.webview.stopFindInPage("clearSelection");
}
function doFind(forward) {
  const t = currentTab();
  const text = findInput.value;
  if (!t || !text) return;
  t.webview.findInPage(text, { forward, findNext: true });
}

findInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") { e.preventDefault(); doFind(!e.shiftKey); }
  if (e.key === "Escape") { e.preventDefault(); closeFindBar(); }
});
findInput.addEventListener("input", () => doFind(true));
document.getElementById("find-next").addEventListener("click", () => doFind(true));
document.getElementById("find-prev").addEventListener("click", () => doFind(false));
document.getElementById("find-close").addEventListener("click", closeFindBar);

// ------------------------------------------------------- search predict --
const suggestionsEl = document.getElementById("suggestions");
let suggestionItems = []; // { type: "bookmark"|"history"|"search", text, url, sub }
let highlightedIndex = -1;
let suggestTimer = null;
let suggestSeq = 0; // guards against a slow, stale fetch overwriting a newer one

function closeSuggestions() {
  suggestionsEl.classList.add("hidden");
  suggestionsEl.innerHTML = "";
  suggestionItems = [];
  highlightedIndex = -1;
}

function renderSuggestions() {
  suggestionsEl.innerHTML = "";
  if (suggestionItems.length === 0) {
    closeSuggestions();
    return;
  }

  const icons = { bookmark: "\u2605", history: "\u{1F553}", search: "\u{1F50D}" };
  let lastType = null;
  suggestionItems.forEach((item, i) => {
    if (item.type !== lastType) {
      const label = document.createElement("div");
      label.className = "sugg-group-label";
      label.textContent = item.type === "search" ? "Search predictions" : "Your history & bookmarks";
      suggestionsEl.appendChild(label);
      lastType = item.type;
    }
    const row = document.createElement("div");
    row.className = "sugg-row" + (i === highlightedIndex ? " highlighted" : "");
    row.innerHTML = `<span class="sugg-icon">${icons[item.type]}</span><span class="sugg-text"></span><span class="sugg-sub"></span>`;
    row.querySelector(".sugg-text").textContent = item.text;
    row.querySelector(".sugg-sub").textContent = item.sub || "";
    row.addEventListener("mousedown", (e) => e.preventDefault()); // keep focus in the input
    row.addEventListener("click", () => pickSuggestion(item));
    suggestionsEl.appendChild(row);
  });
  suggestionsEl.classList.remove("hidden");
}

function pickSuggestion(item) {
  const t = currentTab();
  if (!t) return;
  t.webview.loadURL(item.type === "search" ? normalize(item.text) : item.url);
  closeSuggestions();
  urlbar.blur();
}

async function updateSuggestions(query) {
  const q = query.trim();
  const mySeq = ++suggestSeq;
  if (!q) {
    closeSuggestions();
    return;
  }

  // Local matches first — your own bookmarks/history are more likely to be
  // where you're actually headed than a generic prediction is.
  const { bookmarks, history } = await window.zaris.data.get();
  const qLower = q.toLowerCase();
  const matches = (list) =>
    list.filter((e) => e.title.toLowerCase().includes(qLower) || e.url.toLowerCase().includes(qLower));

  const local = [
    ...matches(bookmarks).slice(0, 2).map((b) => ({ type: "bookmark", text: b.title, url: b.url, sub: b.url })),
    ...matches(history).slice(0, 2).map((h) => ({ type: "history", text: h.title, url: h.url, sub: h.url })),
  ];

  let remote = [];
  if (!looksLikeUrl(q)) {
    const results = await window.zaris.suggest(q);
    if (mySeq !== suggestSeq) return; // a newer keystroke has already superseded this fetch
    remote = results
      .filter((s) => s.toLowerCase() !== qLower)
      .slice(0, 5)
      .map((s) => ({ type: "search", text: s }));
  }
  if (mySeq !== suggestSeq) return;

  suggestionItems = [...local, ...remote];
  highlightedIndex = -1;
  renderSuggestions();
}

urlbar.addEventListener("input", () => {
  clearTimeout(suggestTimer);
  const value = urlbar.value;
  suggestTimer = setTimeout(() => updateSuggestions(value), 150);
});

window.addEventListener("click", (e) => {
  if (!e.target.closest(".urlbar-wrap")) closeSuggestions();
});

// ------------------------------------------------------------- controls --
urlbar.addEventListener("keydown", (e) => {
  if (e.key === "ArrowDown" && suggestionItems.length > 0) {
    e.preventDefault();
    highlightedIndex = Math.min(highlightedIndex + 1, suggestionItems.length - 1);
    renderSuggestions();
    return;
  }
  if (e.key === "ArrowUp" && suggestionItems.length > 0) {
    e.preventDefault();
    highlightedIndex = Math.max(highlightedIndex - 1, -1);
    renderSuggestions();
    return;
  }
  if (e.key === "Escape" && suggestionItems.length > 0) {
    closeSuggestions();
    return;
  }
  if (e.key === "Enter") {
    const t = currentTab();
    if (!t) return;
    if (highlightedIndex >= 0 && suggestionItems[highlightedIndex]) {
      pickSuggestion(suggestionItems[highlightedIndex]);
      return;
    }
    closeSuggestions();
    t.webview.loadURL(normalize(urlbar.value));
    t.webview.focus();
  }
});
urlbar.addEventListener("focus", () => urlbar.select());

btnBack.addEventListener("click", () => currentTab()?.webview.goBack());
btnFwd.addEventListener("click", () => currentTab()?.webview.goForward());
btnReload.addEventListener("click", () => currentTab()?.webview.reload());
btnHome.addEventListener("click", () => currentTab()?.webview.loadURL(START_URL));
btnNewtab.addEventListener("click", () => createTab(START_URL));

// ------------------------------------------------------------- titlebar --
const winMin = document.getElementById("win-min");
const winMax = document.getElementById("win-max");
const winClose = document.getElementById("win-close");

winMin.addEventListener("click", () => window.zaris.window.minimize());
winMax.addEventListener("click", () => window.zaris.window.maximize());
winClose.addEventListener("click", () => window.zaris.window.close());

function setMaximizedIcon(isMax) {
  winMax.innerHTML = isMax ? "&#10064;" : "&#9633;"; // restore glyph vs. plain square
  winMax.title = isMax ? "Restore" : "Maximize";
}
window.zaris.window.isMaximized().then(setMaximizedIcon);
window.zaris.window.onMaximizedChange(setMaximizedIcon);
document.getElementById("titlebar").addEventListener("dblclick", (e) => {
  if (e.target.id === "titlebar" || e.target.id === "app-name") window.zaris.window.maximize();
});

btnStar.addEventListener("click", async () => {
  const t = currentTab();
  if (!t || isInternalUrl(t.url)) return;
  const already = btnStar.classList.contains("active");
  if (already) {
    const all = await window.zaris.data.get();
    const match = all.bookmarks.find((b) => b.url === t.url);
    if (match) await window.zaris.data.removeBookmark(match.id);
  } else {
    await window.zaris.data.addBookmark(t.title, t.url);
  }
  btnStar.classList.toggle("active", !already);
  if (libraryPanel.classList.contains("visible")) renderBookmarks();
});

btnShield.addEventListener("click", () => {
  blockingEnabled = !blockingEnabled;
  btnShield.classList.toggle("blocking-off", !blockingEnabled);
  btnShield.title = blockingEnabled ? "Ad/tracker blocking: on" : "Ad/tracker blocking: off (reload tabs)";
  // Full runtime toggling of the session-level blocker is a main-process
  // concern; wire this up to an ipc call to main.js if you want the button
  // to flip actual filtering rather than just its own indicator.
});

// ----------------------------------------------------------- shortcuts ---
window.addEventListener("keydown", (e) => {
  const mod = e.ctrlKey || e.metaKey;
  if (mod && e.key.toLowerCase() === "t" && e.shiftKey) { e.preventDefault(); reopenClosedTab(); return; }
  if (mod && e.key.toLowerCase() === "t") { e.preventDefault(); createTab(START_URL); }
  if (mod && e.key.toLowerCase() === "w") { e.preventDefault(); if (activeId !== null) closeTab(activeId); }
  if (mod && e.key.toLowerCase() === "l") { e.preventDefault(); urlbar.focus(); }
  if (mod && e.key.toLowerCase() === "r") { e.preventDefault(); currentTab()?.webview.reload(); }
  if (mod && e.key.toLowerCase() === "f") { e.preventDefault(); openFindBar(); }
  if (mod && e.key.toLowerCase() === "d") { e.preventDefault(); btnStar.click(); }
  if (mod && e.key.toLowerCase() === "j") { e.preventDefault(); openLibrary("downloads"); }
  if (e.altKey && e.key === "ArrowLeft") { e.preventDefault(); currentTab()?.webview.goBack(); }
  if (e.altKey && e.key === "ArrowRight") { e.preventDefault(); currentTab()?.webview.goForward(); }
  if (e.altKey && e.key === "Home") { e.preventDefault(); currentTab()?.webview.loadURL(START_URL); }
  if (mod && e.key === "Tab") {
    e.preventDefault();
    if (tabs.length < 2) return;
    const idx = tabs.findIndex((t) => t.id === activeId);
    const next = tabs[(idx + 1) % tabs.length];
    activateTab(next.id);
  }
});

// Links a page tries to pop open as a new OS window arrive here instead.
window.zaris.onOpenTab((url) => createTab(url));

// ---------------------------------------------------------- session restore
async function restoreSession() {
  let saved = null;
  try {
    saved = await window.zaris.session.get();
  } catch {
    // ignore — falls through to a fresh home tab below
  }

  if (!saved || !Array.isArray(saved.tabs) || saved.tabs.length === 0) {
    createTab(START_URL);
    return;
  }

  let toActivate = null;
  saved.tabs.forEach((entry, i) => {
    const url = entry.url === "zaris://home" ? START_URL : entry.url;
    const tab = createTab(url);
    if (entry.pinned) togglePin(tab);
    if (i === saved.activeIndex) toActivate = tab;
  });
  // Reopened tabs don't carry over their own back/forward history — just
  // their last known URL — which is a smaller thing than losing the whole
  // session, but worth knowing if "back" feels like it starts from scratch.
  activateTab((toActivate || tabs[tabs.length - 1]).id);
}

restoreSession();

// ------------------------------------------------------- save my password?
const credBanner = document.createElement("div");
credBanner.id = "cred-banner";
credBanner.className = "hidden";
credBanner.innerHTML = `
  <span class="cred-text">Save this password?</span>
  <button class="cred-btn cred-save">Save</button>
  <button class="cred-btn cred-never">Never for this site</button>
  <button class="cred-btn cred-dismiss">Not now</button>`;
document.body.appendChild(credBanner);

let pendingCred = null;
window.zaris.creds.onOfferSave((data) => {
  pendingCred = data;
  credBanner.querySelector(".cred-text").textContent = `Save password for ${data.username} on ${data.hostname}?`;
  credBanner.classList.remove("hidden");
});
credBanner.querySelector(".cred-save").addEventListener("click", async () => {
  if (pendingCred) await window.zaris.creds.save(pendingCred.hostname, pendingCred.username, pendingCred.password);
  pendingCred = null;
  credBanner.classList.add("hidden");
});
credBanner.querySelector(".cred-never").addEventListener("click", () => {
  pendingCred = null;
  credBanner.classList.add("hidden");
});
credBanner.querySelector(".cred-dismiss").addEventListener("click", () => {
  pendingCred = null;
  credBanner.classList.add("hidden");
});

// Clean fade-in on launch rather than the window just snapping into view.
// Double rAF ensures the browser has committed the opacity:0 starting state
// before the transition to 1 is triggered, so it reliably animates.
requestAnimationFrame(() => requestAnimationFrame(() => document.body.classList.add("ready")));
