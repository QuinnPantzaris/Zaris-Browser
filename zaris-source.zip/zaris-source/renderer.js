const webviewsEl = document.getElementById("webviews");
const tabstripEl = document.getElementById("tabstrip");
const urlbar = document.getElementById("urlbar");
const btnBack = document.getElementById("btn-back");
const btnFwd = document.getElementById("btn-fwd");
const btnReload = document.getElementById("btn-reload");
const btnHome = document.getElementById("btn-home");
const btnNewtab = document.getElementById("btn-newtab");
const btnShield = document.getElementById("btn-shield");
const btnStar = document.getElementById("btn-star");
const btnPalette = document.getElementById("btn-palette");
const btnLibrary = document.getElementById("btn-library");

const findbar = document.getElementById("findbar");
const findInput = document.getElementById("find-input");
const findCount = document.getElementById("find-count");

const libraryOverlay = document.getElementById("library-overlay");
const libraryPanel = document.getElementById("library-panel");

const cpOverlay = document.getElementById("command-palette-overlay");
const commandPalette = document.getElementById("command-palette");
const cpInput = document.getElementById("cp-input");
const cpResults = document.getElementById("cp-results");

// Resolved once, up front, to an absolute file:// URL — see the comment on
// homePage() in preload.js for why this can't just be the bare string
// "startpage.html" anymore.
const START_URL = window.zaris.homePage();
// Brave Search instead of DuckDuckGo's bare /html/ endpoint: real dark theme,
// actual image results, still a privacy-respecting independent index.
const SEARCH_URL = "https://search.brave.com/search?q=";

const MAX_AUTO_RETRIES = 2;
const RETRY_DELAY_MS = 500;

let tabs = [];      // { id, webview, tabEl, title, url }
let activeId = null;
let nextId = 1;
let blockingEnabled = true; // cosmetic toggle; actual filtering lives in main.js session
let closedTabs = []; // stack of { url, pinned } for Ctrl+Shift+T

function looksLikeUrl(raw) {
  return /^[a-zA-Z]+:\/\//.test(raw) || (/^[\w-]+(\.[\w-]+)+(\/.*)?$/.test(raw) && !raw.includes(" "));
}

function normalize(raw) {
  raw = raw.trim();
  if (!raw) return START_URL;
  if (raw === "zaris://home" || raw === "zaris:home") return START_URL;
  // Never let the address bar execute script/data URIs — typing or pasting
  // one of these should search for it as text, not run it.
  if (/^\s*(javascript|data|vbscript):/i.test(raw)) return SEARCH_URL + encodeURIComponent(raw);
  if (looksLikeUrl(raw)) return raw.startsWith("http") || raw.startsWith("file") ? raw : "https://" + raw;
  return SEARCH_URL + encodeURIComponent(raw);
}

function isInternalUrl(url) {
  return url === START_URL || url.endsWith("startpage.html") || url.includes("error.html") || url.endsWith("notes.html");
}

const historyTimers = new Map();
function scheduleHistoryRecord(tab) {
  if (isInternalUrl(tab.url) || tab.temporary) return;
  clearTimeout(historyTimers.get(tab.id));
  // Wait a beat so page-title-updated has a chance to fire first — recording
  // "New tab" as the title for every visit isn't useful.
  historyTimers.set(
    tab.id,
    setTimeout(() => {
      window.zaris.data.addHistory(tab.title, tab.url);
      historyTimers.delete(tab.id);
    }, 700)
  );
}

let sessionSaveTimer = null;
function scheduleSessionSave() {
  clearTimeout(sessionSaveTimer);
  sessionSaveTimer = setTimeout(() => {
    const persistable = tabs.filter((t) => !t.temporary);
    const snapshot = {
      activeIndex: persistable.findIndex((t) => t.id === activeId),
      tabs: persistable.map((t) => ({
        url: isInternalUrl(t.url) ? "zaris://home" : t.url,
        pinned: t.pinned,
      })),
    };
    window.zaris.session.save(snapshot);
  }, 400);
}

function findExistingTabForUrl(url) {
  if (isInternalUrl(url)) return null; // opening another home tab, etc. is always fine
  return tabs.find((t) => t.url === url) || null;
}

function createTab(url, options = {}) {
  const { allowDuplicate = false, temporary = false } = options;

  if (!allowDuplicate) {
    const existing = findExistingTabForUrl(url);
    if (existing) {
      activateTab(existing.id);
      existing.tabEl.classList.remove("pulse");
      requestAnimationFrame(() => existing.tabEl.classList.add("pulse"));
      showDupeToast(url, existing.tabEl);
      return existing;
    }
  }

  const id = nextId++;

  const webview = document.createElement("webview");
  webview.setAttribute("allowpopups", "true");
  // plugins=yes turns on Chromium's built-in PDF viewer (open a PDF in a tab
  // instead of it just forcing a download); sandbox=no lets the preload
  // below use ipcRenderer for autofill.
  webview.setAttribute("webpreferences", "spellcheck=yes,plugins=yes,sandbox=no");
  webview.setAttribute("preload", window.zaris.webviewPreload());
  webview.src = url || START_URL;
  webviewsEl.appendChild(webview);

  const tabEl = document.createElement("div");
  tabEl.className = "tab" + (temporary ? " temporary" : "");
  tabEl.innerHTML = `<span class="title">New tab</span><span class="close">&times;</span>`;
  if (temporary) tabEl.title = "Temporary tab — won't be saved to history or restored on restart";
  tabEl.addEventListener("click", (e) => {
    if (e.target.classList.contains("close")) {
      closeTab(id);
    } else {
      activateTab(id);
    }
  });
  tabstripEl.appendChild(tabEl);

  const tab = { id, webview, tabEl, title: "New tab", url: webview.src, pinned: false, retryCount: 0, temporary, sleeping: false, lastActiveAt: Date.now() };
  tabs.push(tab);

  // ---- drag-to-reorder -----------------------------------------------
  tabEl.draggable = true;
  tabEl.addEventListener("dragstart", (e) => {
    e.dataTransfer.setData("text/zaris-tab-id", String(id));
    e.dataTransfer.effectAllowed = "move";
    requestAnimationFrame(() => tabEl.classList.add("dragging"));
  });
  tabEl.addEventListener("dragend", () => tabEl.classList.remove("dragging"));
  tabEl.addEventListener("dragover", (e) => {
    e.preventDefault();
    const rect = tabEl.getBoundingClientRect();
    const before = e.clientX - rect.left < rect.width / 2;
    tabEl.classList.toggle("drag-over-left", before);
    tabEl.classList.toggle("drag-over-right", !before);
  });
  tabEl.addEventListener("dragleave", () => {
    tabEl.classList.remove("drag-over-left", "drag-over-right");
  });
  tabEl.addEventListener("drop", (e) => {
    e.preventDefault();
    tabEl.classList.remove("drag-over-left", "drag-over-right");
    const draggedId = Number(e.dataTransfer.getData("text/zaris-tab-id"));
    if (draggedId === id) return;
    const rect = tabEl.getBoundingClientRect();
    const before = e.clientX - rect.left < rect.width / 2;
    reorderTab(draggedId, id, before);
  });

  // ---- right-click: tab organization menu -----------------------------
  tabEl.addEventListener("contextmenu", (e) => {
    e.preventDefault();
    showTabMenu(e.clientX, e.clientY, tab);
  });

  webview.addEventListener("page-title-updated", (e) => {
    tab.title = e.title || tab.title;
    tabEl.querySelector(".title").textContent = tab.title;
  });
  webview.addEventListener("did-navigate", (e) => {
    tab.url = e.url;
    if (id === activeId) syncNavState();
    scheduleHistoryRecord(tab);
    scheduleSessionSave();
  });
  webview.addEventListener("did-navigate-in-page", (e) => {
    tab.url = e.url;
    if (id === activeId) syncNavState();
  });
  webview.addEventListener("found-in-page", (e) => {
    if (tab.id !== activeId) return;
    const { activeMatchOrdinal, matches } = e.result;
    findCount.textContent = matches > 0 ? `${activeMatchOrdinal}/${matches}` : "0/0";
  });

  webview.addEventListener("did-finish-load", () => {
    tab.retryCount = 0; // a real, complete load means whatever failed before is over
  });
  webview.addEventListener("did-fail-load", (e) => {
    if (!e.isMainFrame) return;               // a blocked ad iframe failing isn't "the page" failing
    if (e.errorCode === -3 || e.errorCode === 0) return; // aborted / not a real error
    if (e.validatedURL.startsWith(window.zaris.errorPage(""))) return; // don't loop on the error page itself

    // Transient failures (a page loading before the network's fully up, a
    // webview that isn't quite ready right at launch, a momentary blip)
    // deserve a couple of quiet retries before bothering you with an error
    // page — most of them resolve themselves within a few hundred ms.
    if (tab.retryCount < MAX_AUTO_RETRIES) {
      tab.retryCount++;
      setTimeout(() => {
        // Guard against retrying a tab that's since navigated elsewhere or closed.
        if (tabs.includes(tab)) webview.loadURL(e.validatedURL);
      }, RETRY_DELAY_MS);
      return;
    }

    tab.retryCount = 0;
    webview.loadURL(
      window.zaris.errorPage({
        url: e.validatedURL,
        code: String(e.errorCode),
        desc: e.errorDescription || "",
      })
    );
  });

  // A tab's own renderer process can die independently of the app itself
  // (a heavy page, a bad extension-like script, memory pressure) — without
  // this it just sits there frozen with no way back short of closing the tab.
  const handleCrash = (details) => {
    if (details && details.reason === "clean-exit") return; // a deliberate close, not a crash
    webview.loadURL(
      window.zaris.errorPage({ url: tab.url, code: "CRASHED", desc: (details && details.reason) || "" })
    );
  };
  webview.addEventListener("crashed", () => handleCrash());
  webview.addEventListener("render-process-gone", (e) => handleCrash(e.details));

  // Electron/Chromium quirk: a <webview> that's made visible for the very
  // first time right after being created sometimes doesn't paint until
  // something forces a relayout — this is why the logo didn't show up until
  // a second tab existed. Force one on first dom-ready.
  webview.addEventListener(
    "dom-ready",
    () => {
      if (tab.id !== activeId) return;
      webview.classList.remove("active");
      requestAnimationFrame(() => {
        if (tab.id === activeId) webview.classList.add("active");
      });
    },
    { once: true }
  );

  activateTab(id);
  updateTabStripVisibility();
  return tab;
}

function activateTab(id) {
  const previous = tabs.find((t) => t.id === activeId);
  if (previous) previous.lastActiveAt = Date.now();

  activeId = id;
  for (const t of tabs) {
    const active = t.id === id;
    t.webview.classList.toggle("active", active);
    t.tabEl.classList.toggle("active", active);
  }
  const activated = tabs.find((t) => t.id === id);
  if (activated) {
    activated.lastActiveAt = Date.now();
    if (activated.sleeping) wakeTab(activated);
  }
  syncNavState();
  scheduleSessionSave();
}

// ---------------------------------------------------------------- sleeping
// Frees the actual Chromium renderer process behind a background tab by
// unloading its page — this is the one part of "low RAM usage" Electron
// genuinely lets us do something real about, since every open tab is its
// own full process underneath. Pinned/audible/temporary tabs are left alone:
// pinned tabs are your regulars (waking them constantly defeats the point),
// temporary tabs are short-lived by design, and a tab making sound is
// probably a tab you still care about.
const SLEEP_AFTER_MS = 15 * 60 * 1000;
const SLEEP_CHECK_INTERVAL_MS = 60 * 1000;

function sleepTab(tab) {
  if (tab.sleeping || tab.id === activeId || tab.pinned) return;
  try {
    if (tab.webview.isAudioMuted?.() === false && tab.webview.isCurrentlyAudible?.()) return;
  } catch {
    /* isCurrentlyAudible isn't available on every Electron version — fail open and sleep it anyway */
  }
  tab.sleeping = true;
  tab.sleepUrl = tab.url;
  tab.webview.src = "about:blank";
  tab.tabEl.classList.add("sleeping");
}

function wakeTab(tab) {
  tab.sleeping = false;
  tab.tabEl.classList.remove("sleeping");
  if (tab.sleepUrl) tab.webview.loadURL(tab.sleepUrl);
}

setInterval(() => {
  const now = Date.now();
  for (const t of tabs) {
    if (!t.sleeping && t.id !== activeId && !t.pinned && now - t.lastActiveAt > SLEEP_AFTER_MS) {
      sleepTab(t);
    }
  }
}, SLEEP_CHECK_INTERVAL_MS);

function closeTab(id) {
  const idx = tabs.findIndex((t) => t.id === id);
  if (idx === -1) return;
  const [tab] = tabs.splice(idx, 1);

  if (!isInternalUrl(tab.url) && !tab.temporary) {
    closedTabs.push({ url: tab.url, pinned: tab.pinned });
    if (closedTabs.length > 25) closedTabs.shift();
  }

  tab.webview.remove();
  tab.tabEl.remove();

  if (tabs.length === 0) {
    createTab(START_URL);
  } else if (activeId === id) {
    const next = tabs[idx] || tabs[idx - 1] || tabs[0];
    activateTab(next.id);
  }
  updateTabStripVisibility();
  scheduleSessionSave();
}

function reopenClosedTab() {
  const last = closedTabs.pop();
  if (!last) return;
  const tab = createTab(last.url, { allowDuplicate: true });
  if (last.pinned) togglePin(tab);
}

// ---------------------------------------------------------- organization --
function renderTabOrder() {
  // Pinned tabs always sit first, in whatever relative order they're in;
  // unpinned tabs follow. DOM order is made to match the array order.
  tabs.sort((a, b) => (b.pinned === a.pinned ? 0 : b.pinned ? 1 : -1));
  for (const t of tabs) tabstripEl.appendChild(t.tabEl);
  resizeTabs();
  scheduleSessionSave();
}

const MIN_TAB_WIDTH = 44;  // narrow enough to still show a sliver of the title + close button
const MAX_TAB_WIDTH = 200;
const PINNED_TAB_WIDTH = 40;
const TAB_GAP = 6; // matches #tabstrip's CSS gap

function resizeTabs() {
  const unpinned = tabs.filter((t) => !t.pinned);
  if (unpinned.length === 0) return;
  const pinnedCount = tabs.length - unpinned.length;

  const available = tabstripEl.clientWidth - 16 /* strip padding */ - pinnedCount * (PINNED_TAB_WIDTH + TAB_GAP);
  const widthEach = Math.max(MIN_TAB_WIDTH, Math.min(MAX_TAB_WIDTH, Math.floor(available / unpinned.length) - TAB_GAP));

  for (const t of unpinned) {
    t.tabEl.style.width = widthEach + "px";
  }
  // Below the minimum width, tabs stop shrinking further and the strip's
  // own overflow-x: auto takes over — same fallback Chrome/Firefox use once
  // a tab count gets genuinely extreme.
}

window.addEventListener("resize", resizeTabs);

function reorderTab(draggedId, targetId, before) {
  const from = tabs.findIndex((t) => t.id === draggedId);
  const to = tabs.findIndex((t) => t.id === targetId);
  if (from === -1 || to === -1) return;
  const [moved] = tabs.splice(from, 1);
  // Dragging only makes sense within the same pinned/unpinned group.
  moved.pinned = tabs[to] ? tabs[to].pinned : moved.pinned;
  const insertAt = tabs.findIndex((t) => t.id === targetId) + (before ? 0 : 1);
  tabs.splice(insertAt, 0, moved);
  renderTabOrder();
}

function togglePin(tab) {
  tab.pinned = !tab.pinned;
  tab.tabEl.classList.toggle("pinned", tab.pinned);
  renderTabOrder();
}

let dupeToastTimer = null;
function showDupeToast(url, tabEl) {
  clearTimeout(dupeToastTimer);
  let toast = document.getElementById("dupe-toast");
  if (!toast) {
    toast = document.createElement("div");
    toast.id = "dupe-toast";
    toast.innerHTML = `<span>Already open in another tab</span><button id="dupe-open-anyway">Open anyway</button>`;
    document.body.appendChild(toast);
  }
  toast.querySelector("#dupe-open-anyway").onclick = () => {
    createTab(url, { allowDuplicate: true });
    toast.classList.remove("visible");
  };
  requestAnimationFrame(() => toast.classList.add("visible"));
  dupeToastTimer = setTimeout(() => toast.classList.remove("visible"), 3500);
}

function duplicateTab(tab) {
  createTab(tab.url, { allowDuplicate: true });
}

function closeOthers(tab) {
  for (const t of [...tabs]) {
    if (t.id !== tab.id) closeTab(t.id);
  }
}

function closeToRight(tab) {
  const idx = tabs.findIndex((t) => t.id === tab.id);
  for (const t of tabs.slice(idx + 1)) closeTab(t.id);
}

let openTabMenuEl = null;
function closeTabMenu() {
  if (openTabMenuEl) {
    openTabMenuEl.remove();
    openTabMenuEl = null;
  }
}

function showTabMenu(x, y, tab) {
  closeTabMenu();
  const menu = document.createElement("div");
  menu.className = "tab-menu";

  const item = (label, fn, extraClass) => {
    const el = document.createElement("div");
    el.className = "item" + (extraClass ? " " + extraClass : "");
    el.textContent = label;
    el.addEventListener("click", () => { closeTabMenu(); fn(); });
    menu.appendChild(el);
  };
  const sep = () => {
    const el = document.createElement("div");
    el.className = "sep";
    menu.appendChild(el);
  };

  item("New Tab", () => createTab(START_URL));
  item("Duplicate Tab", () => duplicateTab(tab));
  item(tab.pinned ? "Unpin Tab" : "Pin Tab", () => togglePin(tab));
  sep();
  item("Reload Tab", () => tab.webview.reload());
  sep();
  item("Close Tab", () => closeTab(tab.id), "danger");
  item("Close Other Tabs", () => closeOthers(tab), "danger");
  item("Close Tabs to the Right", () => closeToRight(tab), "danger");

  document.body.appendChild(menu);
  const rect = menu.getBoundingClientRect();
  menu.style.left = Math.min(x, window.innerWidth - rect.width - 8) + "px";
  menu.style.top = Math.min(y, window.innerHeight - rect.height - 8) + "px";
  openTabMenuEl = menu;
}

window.addEventListener("click", (e) => {
  if (openTabMenuEl && !openTabMenuEl.contains(e.target)) closeTabMenu();
});
window.addEventListener("keydown", (e) => {
  if (e.key !== "Escape") return;
  if (!commandPalette.classList.contains("hidden")) { closeCommandPalette(); return; }
  if (!findbar.classList.contains("hidden")) { closeFindBar(); return; }
  if (libraryPanel.classList.contains("visible")) { closeLibrary(); return; }
  closeTabMenu();
});

function updateTabStripVisibility() {
  const show = tabs.length > 1;
  tabstripEl.classList.toggle("hidden", !show);
  document.getElementById("webviews").style.top = show ? "118px" : "84px";
  resizeTabs();
}

function currentTab() {
  return tabs.find((t) => t.id === activeId);
}

function syncNavState() {
  const t = currentTab();
  if (!t) return;
  closeSuggestions();
  urlbar.value = (t.url === START_URL || t.url.endsWith("startpage.html")) ? "" : t.url;
  try {
    btnBack.disabled = !t.webview.canGoBack();
    btnFwd.disabled = !t.webview.canGoForward();
  } catch {
    // webview not attached to DOM yet on first tick
  }
  btnStar.style.display = isInternalUrl(t.url) ? "none" : "flex";
  if (!isInternalUrl(t.url)) {
    window.zaris.data.isBookmarked(t.url).then((yes) => {
      // Guard against the tab having changed while this promise was in flight.
      if (currentTab()?.id === t.id) btnStar.classList.toggle("active", yes);
    });
  }
}

// ------------------------------------------------------------- library ---
const libTabs = document.querySelectorAll(".lib-tab");
const libBodies = {
  bookmarks: document.getElementById("lib-bookmarks"),
  history: document.getElementById("lib-history"),
  downloads: document.getElementById("lib-downloads"),
  passwords: document.getElementById("lib-passwords"),
  closed: document.getElementById("lib-closed"),
  health: document.getElementById("lib-health"),
};

function fmtTime(ts) {
  const d = new Date(ts);
  const now = new Date();
  const sameDay = d.toDateString() === now.toDateString();
  return sameDay
    ? d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    : d.toLocaleDateString([], { month: "short", day: "numeric" }) + " · " + d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

function fmtBytes(n) {
  if (!n && n !== 0) return "";
  if (n < 1024) return n + " B";
  if (n < 1024 ** 2) return (n / 1024).toFixed(1) + " KB";
  if (n < 1024 ** 3) return (n / 1024 ** 2).toFixed(1) + " MB";
  return (n / 1024 ** 3).toFixed(2) + " GB";
}

function emptyRow(text) {
  const el = document.createElement("div");
  el.className = "lib-empty";
  el.textContent = text;
  return el;
}

async function renderBookmarks() {
  const { bookmarks } = await window.zaris.data.get();
  const body = libBodies.bookmarks;
  body.innerHTML = "";
  if (bookmarks.length === 0) {
    body.appendChild(emptyRow("No bookmarks yet — click the star in the address bar to save a page."));
    return;
  }
  for (const b of bookmarks) {
    const row = document.createElement("div");
    row.className = "lib-row";
    row.innerHTML = `
      <div class="row-main">
        <div class="row-title"></div>
        <div class="row-sub"></div>
      </div>
      <button class="row-remove" title="Remove bookmark">&times;</button>`;
    row.querySelector(".row-title").textContent = b.title;
    row.querySelector(".row-sub").textContent = b.url;
    row.addEventListener("click", (e) => {
      if (e.target.classList.contains("row-remove")) return;
      createTab(b.url);
      closeLibrary();
    });
    row.querySelector(".row-remove").addEventListener("click", async (e) => {
      e.stopPropagation();
      await window.zaris.data.removeBookmark(b.id);
      renderBookmarks();
      syncNavState();
    });
    body.appendChild(row);
  }
}

async function renderHistory() {
  const { history } = await window.zaris.data.get();
  const body = libBodies.history;
  body.innerHTML = "";

  const toolbar = document.createElement("div");
  toolbar.className = "lib-toolbar";
  const clearBtn = document.createElement("button");
  clearBtn.textContent = "Clear all history";
  clearBtn.addEventListener("click", async () => {
    await window.zaris.data.clearHistory();
    renderHistory();
  });
  toolbar.appendChild(clearBtn);
  body.appendChild(toolbar);

  if (history.length === 0) {
    body.appendChild(emptyRow("No browsing history yet."));
    return;
  }
  for (const h of history) {
    const row = document.createElement("div");
    row.className = "lib-row";
    row.innerHTML = `
      <div class="row-main">
        <div class="row-title"></div>
        <div class="row-sub"></div>
      </div>
      <button class="row-remove" title="Remove from history">&times;</button>`;
    row.querySelector(".row-title").textContent = h.title;
    row.querySelector(".row-sub").textContent = `${fmtTime(h.visitedAt)} · ${h.url}`;
    row.addEventListener("click", (e) => {
      if (e.target.classList.contains("row-remove")) return;
      createTab(h.url);
      closeLibrary();
    });
    row.querySelector(".row-remove").addEventListener("click", async (e) => {
      e.stopPropagation();
      await window.zaris.data.removeHistoryEntry(h.id);
      renderHistory();
    });
    body.appendChild(row);
  }
}

async function renderDownloads() {
  const { downloads } = await window.zaris.data.get();
  const body = libBodies.downloads;
  body.innerHTML = "";

  const toolbar = document.createElement("div");
  toolbar.className = "lib-toolbar";
  const clearBtn = document.createElement("button");
  clearBtn.textContent = "Clear finished";
  clearBtn.addEventListener("click", async () => {
    await window.zaris.data.clearDownloads();
    renderDownloads();
  });
  toolbar.appendChild(clearBtn);
  body.appendChild(toolbar);

  if (downloads.length === 0) {
    body.appendChild(emptyRow("Nothing downloaded yet."));
  }
  for (const d of downloads) {
    const pct = d.totalBytes > 0 ? Math.min(100, Math.round((d.receivedBytes / d.totalBytes) * 100)) : 0;
    const row = document.createElement("div");
    row.className = "lib-row download-row" + (d.state === "completed" ? " download-done" : d.state === "interrupted" || d.state === "cancelled" ? " download-failed" : "");
    row.dataset.downloadId = d.id;

    const statusText =
      d.queued ? "Queued — waiting for a download slot" :
      d.state === "progressing" ? `${d.paused ? "Paused — " : ""}${fmtBytes(d.receivedBytes)} of ${fmtBytes(d.totalBytes)}` :
      d.state === "completed" ? `${fmtBytes(d.receivedBytes)} · ${fmtTime(d.startedAt)}` :
      d.state === "cancelled" ? "Cancelled" : "Failed";

    row.innerHTML = `
      <div class="row-main">
        <div class="row-title"></div>
        <div class="row-sub"></div>
        ${d.state === "progressing" ? '<div class="row-progress"><div class="row-progress-fill"></div></div>' : ""}
      </div>
      <div class="download-row-actions"></div>`;
    row.querySelector(".row-title").textContent = d.filename;
    row.querySelector(".row-sub").textContent = statusText;
    const fill = row.querySelector(".row-progress-fill");
    if (fill) fill.style.width = pct + "%";

    const actions = row.querySelector(".download-row-actions");
    if (d.state === "progressing" && !d.queued) {
      const toggleBtn = document.createElement("button");
      toggleBtn.className = "row-remove";
      toggleBtn.textContent = d.paused ? "\u25B6" : "\u23F8";
      toggleBtn.title = d.paused ? "Resume" : "Pause";
      toggleBtn.addEventListener("click", async (e) => {
        e.stopPropagation();
        d.paused ? await window.zaris.data.resumeDownload(d.id) : await window.zaris.data.pauseDownload(d.id);
      });
      actions.appendChild(toggleBtn);
    }
    if (d.state === "progressing") {
      const cancelBtn = document.createElement("button");
      cancelBtn.className = "row-remove";
      cancelBtn.textContent = "\u2715";
      cancelBtn.title = "Cancel";
      cancelBtn.addEventListener("click", async (e) => {
        e.stopPropagation();
        await window.zaris.data.cancelDownload(d.id);
      });
      actions.appendChild(cancelBtn);
    }
    if (d.queued) {
      for (const [dir, glyph] of [["up", "\u2191"], ["down", "\u2193"]]) {
        const btn = document.createElement("button");
        btn.className = "row-remove";
        btn.textContent = glyph;
        btn.title = dir === "up" ? "Move up in queue" : "Move down in queue";
        btn.addEventListener("click", async (e) => {
          e.stopPropagation();
          await window.zaris.data.reorderDownload(d.id, dir);
          showTransientToast("Queue order updated");
        });
        actions.appendChild(btn);
      }
    }

    row.addEventListener("click", () => {
      if (d.state === "completed") window.zaris.data.showItemInFolder(d.savePath);
    });
    body.appendChild(row);
  }

  await renderDownloadRules(body);
}

async function renderDownloadRules(container) {
  const rules = await window.zaris.downloadRules.list();

  const section = document.createElement("div");
  section.className = "rules-section";
  section.innerHTML = `
    <div class="sugg-group-label">Automatic download folders</div>
    <div class="rules-list"></div>
    <form class="rules-form">
      <input class="rules-match" placeholder="e.g. github.com" autocomplete="off">
      <span class="rules-arrow">\u2192</span>
      <input class="rules-folder" placeholder="e.g. Projects" autocomplete="off">
      <button type="submit">Add</button>
    </form>`;
  container.appendChild(section);

  const list = section.querySelector(".rules-list");
  if (rules.length === 0) {
    const hint = document.createElement("div");
    hint.className = "lib-empty";
    hint.style.padding = "10px 8px";
    hint.textContent = "No rules yet — downloads from a matching site auto-move into a Downloads subfolder.";
    list.appendChild(hint);
  }
  for (const r of rules) {
    const row = document.createElement("div");
    row.className = "lib-row";
    row.innerHTML = `<div class="row-main"><div class="row-title">${r.match} \u2192 ${r.folder}</div></div>
      <button class="row-remove" title="Remove rule">&times;</button>`;
    row.querySelector(".row-remove").addEventListener("click", async () => {
      await window.zaris.downloadRules.remove(r.id);
      renderDownloads();
    });
    list.appendChild(row);
  }

  section.querySelector(".rules-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const match = section.querySelector(".rules-match").value.trim();
    const folder = section.querySelector(".rules-folder").value.trim();
    if (!match || !folder) return;
    await window.zaris.downloadRules.add(match, folder);
    renderDownloads();
  });
}

// ---------------------------------------------------------- download toasts
const toastContainer = document.createElement("div");
toastContainer.id = "download-toasts";
document.body.appendChild(toastContainer);

const activeToasts = new Map(); // download id -> { el, dismissTimer }
const TOAST_AUTO_DISMISS_MS = 6000;

function scheduleToastDismiss(id) {
  const entry = activeToasts.get(id);
  if (!entry) return;
  clearTimeout(entry.dismissTimer);
  entry.dismissTimer = setTimeout(() => dismissToast(id), TOAST_AUTO_DISMISS_MS);
}

function dismissToast(id) {
  const entry = activeToasts.get(id);
  if (!entry) return;
  clearTimeout(entry.dismissTimer);
  entry.el.classList.add("leaving");
  setTimeout(() => entry.el.remove(), 180);
  activeToasts.delete(id);
}

function renderToast(record) {
  let entry = activeToasts.get(record.id);
  const pct = record.totalBytes > 0 ? Math.min(100, Math.round((record.receivedBytes / record.totalBytes) * 100)) : null;
  const done = record.state !== "progressing";

  if (!entry) {
    const el = document.createElement("div");
    el.className = "download-toast";
    el.innerHTML = `
      <div class="dl-toast-icon">${done ? "\u2193" : "\u2022"}</div>
      <div class="dl-toast-main">
        <div class="dl-toast-name"></div>
        <div class="dl-toast-sub"></div>
        <div class="dl-toast-progress"><div class="dl-toast-progress-fill"></div></div>
      </div>
      <button class="dl-toast-close" title="Dismiss">&times;</button>`;
    el.querySelector(".dl-toast-close").addEventListener("click", (e) => {
      e.stopPropagation();
      dismissToast(record.id);
    });
    el.addEventListener("mouseenter", () => clearTimeout(activeToasts.get(record.id)?.dismissTimer));
    el.addEventListener("mouseleave", () => scheduleToastDismiss(record.id));
    toastContainer.prepend(el);
    entry = { el, dismissTimer: null };
    activeToasts.set(record.id, entry);
  }

  const el = entry.el;
  el.classList.toggle("done", record.state === "completed");
  el.classList.toggle("failed", record.state === "cancelled" || record.state === "interrupted");
  el.querySelector(".dl-toast-icon").textContent = record.state === "completed" ? "\u2713" : record.state === "progressing" ? "\u2193" : "\u2715";
  el.querySelector(".dl-toast-name").textContent = record.filename;
  el.querySelector(".dl-toast-sub").textContent =
    record.state === "progressing"
      ? (pct !== null ? `${pct}% · ${fmtBytes(record.receivedBytes)} of ${fmtBytes(record.totalBytes)}` : fmtBytes(record.receivedBytes))
      : record.state === "completed"
      ? `Done · ${fmtBytes(record.receivedBytes)} — click to show in folder`
      : record.state === "cancelled"
      ? "Cancelled"
      : "Failed";
  const fill = el.querySelector(".dl-toast-progress-fill");
  fill.style.width = (pct ?? (record.state === "progressing" ? 30 : 100)) + "%";
  el.querySelector(".dl-toast-progress").classList.toggle("indeterminate", record.state === "progressing" && pct === null);

  el.onclick = () => {
    if (record.state === "completed") window.zaris.data.showItemInFolder(record.savePath);
  };

  if (done) scheduleToastDismiss(record.id);
  else clearTimeout(entry.dismissTimer); // still going — don't let a stale timer kill it mid-download
}

window.zaris.data.onDownloadUpdate((record) => {
  if (libraryPanel.classList.contains("visible")) renderDownloads();
  renderToast(record);
});

async function renderPasswords() {
  const list = await window.zaris.creds.list();
  const body = libBodies.passwords;
  body.innerHTML = "";

  const note = document.createElement("div");
  note.className = "lib-toolbar";
  note.style.justifyContent = "flex-start";
  note.style.color = "var(--text-mute)";
  note.style.fontSize = "11px";
  note.style.padding = "4px 8px 10px 8px";
  note.textContent = "Passwords are encrypted on disk and never shown here — remove is the only action.";
  body.appendChild(note);

  if (list.length === 0) {
    body.appendChild(emptyRow("No saved passwords yet."));
    return;
  }
  for (const c of list) {
    const row = document.createElement("div");
    row.className = "lib-row";
    row.innerHTML = `
      <div class="row-main">
        <div class="row-title"></div>
        <div class="row-sub"></div>
      </div>
      <button class="row-remove" title="Remove saved password">&times;</button>`;
    row.querySelector(".row-title").textContent = c.hostname;
    row.querySelector(".row-sub").textContent = c.username;
    row.querySelector(".row-remove").addEventListener("click", async (e) => {
      e.stopPropagation();
      await window.zaris.creds.remove(c.id);
      renderPasswords();
    });
    body.appendChild(row);
  }
}

function renderRecentlyClosed() {
  const body = libBodies.closed;
  body.innerHTML = "";
  if (closedTabs.length === 0) {
    body.appendChild(emptyRow("Nothing closed recently."));
    return;
  }
  // Most-recently-closed first — closedTabs is a stack, last item = most recent.
  [...closedTabs].reverse().forEach((entry, reverseIdx) => {
    const realIdx = closedTabs.length - 1 - reverseIdx;
    const row = document.createElement("div");
    row.className = "lib-row";
    row.innerHTML = `<div class="row-main"><div class="row-title"></div><div class="row-sub"></div></div>
      <button class="row-remove" title="Remove from this list">&times;</button>`;
    row.querySelector(".row-title").textContent = entry.url;
    row.querySelector(".row-sub").textContent = entry.pinned ? "Was pinned" : "";
    row.addEventListener("click", (e) => {
      if (e.target.classList.contains("row-remove")) return;
      closedTabs.splice(realIdx, 1);
      const tab = createTab(entry.url, { allowDuplicate: true });
      if (entry.pinned) togglePin(tab);
      closeLibrary();
    });
    row.querySelector(".row-remove").addEventListener("click", (e) => {
      e.stopPropagation();
      closedTabs.splice(realIdx, 1);
      renderRecentlyClosed();
    });
    body.appendChild(row);
  });
}

async function renderHealth() {
  const body = libBodies.health;
  body.innerHTML = `<div class="lib-empty">Measuring\u2026</div>`;
  const h = await window.zaris.health.get();
  const sleepingCount = tabs.filter((t) => t.sleeping).length;

  body.innerHTML = "";
  const rows = [
    ["Startup time", h.startupMs != null ? `${(h.startupMs / 1000).toFixed(2)}s` : "\u2014"],
    ["Memory in use", `${h.memoryMB} MB across ${h.processCount} processes`],
    ["Cache size", `${h.cacheMB} MB`],
    ["Open tabs", `${tabs.length} (${sleepingCount} sleeping)`],
    ["History entries", String(h.historyCount)],
    ["Bookmarks", `${h.bookmarkCount}${h.duplicateBookmarks ? ` (${h.duplicateBookmarks} duplicate)` : ""}`],
  ];
  for (const [label, value] of rows) {
    const row = document.createElement("div");
    row.className = "health-row";
    row.innerHTML = `<span class="health-label"></span><span class="health-value"></span>`;
    row.querySelector(".health-label").textContent = label;
    row.querySelector(".health-value").textContent = value;
    body.appendChild(row);
  }

  const clearBtn = document.createElement("button");
  clearBtn.className = "health-clear-btn";
  clearBtn.textContent = "Clear Cache";
  clearBtn.addEventListener("click", async () => {
    clearBtn.disabled = true;
    clearBtn.textContent = "Clearing\u2026";
    await window.zaris.health.clearCache();
    showTransientToast("Cache cleared");
    renderHealth();
  });
  body.appendChild(clearBtn);

  const note = document.createElement("div");
  note.className = "lib-empty";
  note.style.padding = "16px 8px 4px 8px";
  note.textContent = "These are real measured numbers, not a made-up health score.";
  body.appendChild(note);
}

function switchLibTab(name) {
  for (const el of libTabs) el.classList.toggle("active", el.dataset.panel === name);
  for (const key of Object.keys(libBodies)) libBodies[key].classList.toggle("hidden", key !== name);
  if (name === "bookmarks") renderBookmarks();
  if (name === "history") renderHistory();
  if (name === "downloads") renderDownloads();
  if (name === "passwords") renderPasswords();
  if (name === "closed") renderRecentlyClosed();
  if (name === "health") renderHealth();
}

for (const el of libTabs) el.addEventListener("click", () => switchLibTab(el.dataset.panel));

function openLibrary(panel) {
  libraryOverlay.classList.remove("hidden");
  libraryPanel.classList.remove("hidden");
  requestAnimationFrame(() => {
    libraryOverlay.classList.add("visible");
    libraryPanel.classList.add("visible");
  });
  switchLibTab(panel || "bookmarks");
}

function closeLibrary() {
  libraryOverlay.classList.remove("visible");
  libraryPanel.classList.remove("visible");
  setTimeout(() => {
    libraryOverlay.classList.add("hidden");
    libraryPanel.classList.add("hidden");
  }, 220);
}

btnLibrary.addEventListener("click", () => {
  libraryPanel.classList.contains("visible") ? closeLibrary() : openLibrary("bookmarks");
});
document.getElementById("lib-close").addEventListener("click", closeLibrary);
libraryOverlay.addEventListener("click", closeLibrary);

btnPalette.addEventListener("click", () => {
  commandPalette.classList.contains("visible") ? closeCommandPalette() : openCommandPalette();
});

// -------------------------------------------------------- command palette
// One search surface instead of two competing ones — this covers both the
// vision doc's separate "Tab Search" and "Universal Command Palette" ideas,
// since splitting them into two different overlays would just be two
// half-features fighting for the same "search everything" moment. Ctrl+K
// instead of the doc's suggested Ctrl+P, since Ctrl+P is universally "print"
// in every browser — remapping it would break a real, expected shortcut
// just to match a made-up convention, which fails the doc's own "does this
// remove friction" test.
let cpItems = [];
let cpHighlighted = -1;

function focusModeActive() {
  return document.body.classList.contains("focus-mode");
}

function toggleFocusMode() {
  const entering = !focusModeActive();
  document.body.classList.toggle("focus-mode", entering);
  document.getElementById("webviews").style.top = entering ? "34px" : (tabs.length > 1 ? "118px" : "84px");
  if (entering) showTransientToast("Focus mode — Ctrl+Shift+F to exit");
}

function buildCommandItems() {
  const items = [];
  for (const t of tabs) {
    if (t.id === activeId) continue;
    items.push({ icon: "\u25A2", label: t.title, sub: isInternalUrl(t.url) ? "" : t.url, action: () => activateTab(t.id), group: "Open tabs" });
  }
  items.push(
    { icon: "+", label: "New Tab", sub: "Ctrl+T", action: () => createTab(START_URL), group: "Commands" },
    { icon: "\u25CE", label: "New Temporary Tab", sub: "Ctrl+Shift+N — not saved to history", action: () => createTab(START_URL, { temporary: true }), group: "Commands" },
    { icon: "\u25A3", label: focusModeActive() ? "Exit Focus Mode" : "Enter Focus Mode", sub: "Ctrl+Shift+F", action: toggleFocusMode, group: "Commands" },
    { icon: "\u2318", label: "Take Screenshot (Visible Area)", sub: "Ctrl+Shift+S", action: () => takeScreenshot("visible"), group: "Commands" },
    { icon: "\u2750", label: "Take Screenshot (Select Region)", action: () => takeScreenshot("region"), group: "Commands" },
    { icon: "\u270E", label: "Open Notes", action: () => createTab(window.zaris.notesPage(), { allowDuplicate: false }), group: "Commands" },
    { icon: "\u25CF", label: blockingEnabled ? "Turn Off Ad Blocking (this tab)" : "Turn On Ad Blocking (this tab)", action: () => btnShield.click(), group: "Commands" },
    { icon: "\u2261", label: "Open Library", sub: "Ctrl+J", action: () => openLibrary("bookmarks"), group: "Commands" },
    { icon: "\u21BA", label: "Reopen Closed Tab", sub: "Ctrl+Shift+T", action: reopenClosedTab, group: "Commands" },
    { icon: "\u2717", label: "Clear Browser Cache", action: async () => { await window.zaris.health.clearCache(); showTransientToast("Cache cleared"); }, group: "Commands" }
  );
  return items;
}

async function filterCommandItems(query) {
  const base = buildCommandItems();
  if (!query.trim()) return base.slice(0, 12);

  const q = query.toLowerCase();
  const matched = base.filter((i) => i.label.toLowerCase().includes(q) || (i.sub && i.sub.toLowerCase().includes(q)));

  const { bookmarks, history } = await window.zaris.data.get();
  const bMatches = bookmarks
    .filter((b) => b.title.toLowerCase().includes(q) || b.url.toLowerCase().includes(q))
    .slice(0, 5)
    .map((b) => ({ icon: "\u2605", label: b.title, sub: b.url, action: () => createTab(b.url), group: "Bookmarks" }));
  const hMatches = history
    .filter((h) => h.title.toLowerCase().includes(q) || h.url.toLowerCase().includes(q))
    .slice(0, 5)
    .map((h) => ({ icon: "\u25D4", label: h.title, sub: h.url, action: () => createTab(h.url), group: "History" }));

  const result = [...matched, ...bMatches, ...hMatches];
  result.push({
    icon: "\u{1F50E}\u{FE0E}",
    label: `Search Brave for "${query}"`,
    action: () => createTab(normalize(query)),
    group: "Search",
  });
  return result;
}

function renderCommandItems() {
  cpResults.innerHTML = "";
  let lastGroup = null;
  cpItems.forEach((item, i) => {
    if (item.group !== lastGroup) {
      const label = document.createElement("div");
      label.className = "sugg-group-label";
      label.textContent = item.group;
      cpResults.appendChild(label);
      lastGroup = item.group;
    }
    const row = document.createElement("div");
    row.className = "sugg-row" + (i === cpHighlighted ? " highlighted" : "");
    row.innerHTML = `<span class="sugg-icon">${item.icon}</span><span class="sugg-text"></span><span class="sugg-sub"></span>`;
    row.querySelector(".sugg-text").textContent = item.label;
    row.querySelector(".sugg-sub").textContent = item.sub || "";
    row.addEventListener("mousedown", (e) => e.preventDefault());
    row.addEventListener("click", () => runCommandItem(item));
    cpResults.appendChild(row);
  });
}

function runCommandItem(item) {
  closeCommandPalette();
  item.action();
}

async function updateCommandItems() {
  cpItems = await filterCommandItems(cpInput.value);
  cpHighlighted = cpItems.length > 0 ? 0 : -1;
  renderCommandItems();
}

function openCommandPalette() {
  cpOverlay.classList.remove("hidden");
  commandPalette.classList.remove("hidden");
  requestAnimationFrame(() => {
    cpOverlay.classList.add("visible");
    commandPalette.classList.add("visible");
  });
  cpInput.value = "";
  cpInput.focus();
  updateCommandItems();
}

function closeCommandPalette() {
  cpOverlay.classList.remove("visible");
  commandPalette.classList.remove("visible");
  setTimeout(() => {
    cpOverlay.classList.add("hidden");
    commandPalette.classList.add("hidden");
  }, 180);
}

cpOverlay.addEventListener("click", closeCommandPalette);
cpInput.addEventListener("input", updateCommandItems);
cpInput.addEventListener("keydown", (e) => {
  if (e.key === "ArrowDown") { e.preventDefault(); cpHighlighted = Math.min(cpHighlighted + 1, cpItems.length - 1); renderCommandItems(); }
  if (e.key === "ArrowUp") { e.preventDefault(); cpHighlighted = Math.max(cpHighlighted - 1, 0); renderCommandItems(); }
  if (e.key === "Enter" && cpItems[cpHighlighted]) { e.preventDefault(); runCommandItem(cpItems[cpHighlighted]); }
});

// ---------------------------------------------------- transient toast ----
// A small reusable banner for one-off confirmations ("Cache cleared",
// "Focus mode on") — distinct from the download toasts, which need to
// track ongoing progress rather than just say something once and fade.
let transientToastTimer = null;
function showTransientToast(text) {
  let el = document.getElementById("transient-toast");
  if (!el) {
    el = document.createElement("div");
    el.id = "transient-toast";
    document.body.appendChild(el);
  }
  el.textContent = text;
  clearTimeout(transientToastTimer);
  requestAnimationFrame(() => el.classList.add("visible"));
  transientToastTimer = setTimeout(() => el.classList.remove("visible"), 2600);
}

// -------------------------------------------------------------- screenshot
async function takeScreenshot(mode) {
  const t = currentTab();
  if (!t) return;
  try {
    const image = await t.webview.capturePage();
    const dataUrl = image.toDataURL();
    if (mode === "visible") {
      await saveScreenshot(dataUrl);
    } else {
      openRegionSelector(dataUrl);
    }
  } catch (err) {
    showTransientToast("Screenshot failed");
  }
}

async function saveScreenshot(dataUrl) {
  const result = await window.zaris.screenshot.save(dataUrl);
  if (result.ok) {
    showTransientToast("Screenshot saved");
  } else {
    showTransientToast("Couldn't save screenshot");
  }
}

function openRegionSelector(dataUrl) {
  const overlay = document.createElement("div");
  overlay.id = "region-select-overlay";
  const box = document.createElement("div");
  box.id = "region-select-box";
  overlay.appendChild(box);
  document.body.appendChild(overlay);

  let start = null;
  overlay.addEventListener("mousedown", (e) => {
    start = { x: e.clientX, y: e.clientY };
    box.style.left = start.x + "px";
    box.style.top = start.y + "px";
    box.style.width = "0px";
    box.style.height = "0px";
    box.classList.add("active");
  });
  overlay.addEventListener("mousemove", (e) => {
    if (!start) return;
    const x = Math.min(start.x, e.clientX);
    const y = Math.min(start.y, e.clientY);
    box.style.left = x + "px";
    box.style.top = y + "px";
    box.style.width = Math.abs(e.clientX - start.x) + "px";
    box.style.height = Math.abs(e.clientY - start.y) + "px";
  });
  overlay.addEventListener("mouseup", async (e) => {
    if (!start) return;
    const rect = box.getBoundingClientRect();
    overlay.remove();
    if (rect.width < 4 || rect.height < 4) return; // treat a stray click as "cancel"

    const img = new Image();
    img.onload = async () => {
      // The captured NativeImage is at device-pixel resolution; the
      // selection box was drawn in CSS pixels, so scale by the ratio
      // between the two before cropping.
      const scaleX = img.width / window.innerWidth;
      const scaleY = img.height / (window.innerHeight);
      const canvas = document.createElement("canvas");
      canvas.width = rect.width * scaleX;
      canvas.height = rect.height * scaleY;
      const ctx = canvas.getContext("2d");
      ctx.drawImage(img, rect.left * scaleX, rect.top * scaleY, canvas.width, canvas.height, 0, 0, canvas.width, canvas.height);
      await saveScreenshot(canvas.toDataURL("image/png"));
    };
    img.src = dataUrl;
  });
  overlay.addEventListener("keydown", (e) => {
    if (e.key === "Escape") overlay.remove();
  });
}


// ------------------------------------------------------------ find bar ---
function openFindBar() {
  findbar.classList.remove("hidden");
  findInput.value = "";
  findCount.textContent = "";
  findInput.focus();
}
function closeFindBar() {
  findbar.classList.add("hidden");
  currentTab()?.webview.stopFindInPage("clearSelection");
}
function doFind(forward) {
  const t = currentTab();
  const text = findInput.value;
  if (!t || !text) return;
  t.webview.findInPage(text, { forward, findNext: true });
}

findInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") { e.preventDefault(); doFind(!e.shiftKey); }
  if (e.key === "Escape") { e.preventDefault(); closeFindBar(); }
});
findInput.addEventListener("input", () => doFind(true));
document.getElementById("find-next").addEventListener("click", () => doFind(true));
document.getElementById("find-prev").addEventListener("click", () => doFind(false));
document.getElementById("find-close").addEventListener("click", closeFindBar);

// ------------------------------------------------------- search predict --
const suggestionsEl = document.getElementById("suggestions");
let suggestionItems = []; // { type: "bookmark"|"history"|"search", text, url, sub }
let highlightedIndex = -1;
let suggestTimer = null;
let suggestSeq = 0; // guards against a slow, stale fetch overwriting a newer one

function closeSuggestions() {
  suggestionsEl.classList.add("hidden");
  suggestionsEl.innerHTML = "";
  suggestionItems = [];
  highlightedIndex = -1;
}

function renderSuggestions() {
  suggestionsEl.innerHTML = "";
  if (suggestionItems.length === 0) {
    closeSuggestions();
    return;
  }

  const icons = { bookmark: "\u2605", history: "\u25D4", search: "\u{1F50E}\u{FE0E}" };
  let lastType = null;
  suggestionItems.forEach((item, i) => {
    if (item.type !== lastType) {
      const label = document.createElement("div");
      label.className = "sugg-group-label";
      label.textContent = item.type === "search" ? "Search predictions" : "Your history & bookmarks";
      suggestionsEl.appendChild(label);
      lastType = item.type;
    }
    const row = document.createElement("div");
    row.className = "sugg-row" + (i === highlightedIndex ? " highlighted" : "");
    row.innerHTML = `<span class="sugg-icon">${icons[item.type]}</span><span class="sugg-text"></span><span class="sugg-sub"></span>`;
    row.querySelector(".sugg-text").textContent = item.text;
    row.querySelector(".sugg-sub").textContent = item.sub || "";
    row.addEventListener("mousedown", (e) => e.preventDefault()); // keep focus in the input
    row.addEventListener("click", () => pickSuggestion(item));
    suggestionsEl.appendChild(row);
  });
  suggestionsEl.classList.remove("hidden");
}

function pickSuggestion(item) {
  const t = currentTab();
  if (!t) return;
  t.webview.loadURL(item.type === "search" ? normalize(item.text) : item.url);
  closeSuggestions();
  urlbar.blur();
}

async function updateSuggestions(query) {
  const q = query.trim();
  const mySeq = ++suggestSeq;
  if (!q) {
    closeSuggestions();
    return;
  }

  // Local matches first — your own bookmarks/history are more likely to be
  // where you're actually headed than a generic prediction is.
  const { bookmarks, history } = await window.zaris.data.get();
  const qLower = q.toLowerCase();
  const matches = (list) =>
    list.filter((e) => e.title.toLowerCase().includes(qLower) || e.url.toLowerCase().includes(qLower));

  const local = [
    ...matches(bookmarks).slice(0, 2).map((b) => ({ type: "bookmark", text: b.title, url: b.url, sub: b.url })),
    ...matches(history).slice(0, 2).map((h) => ({ type: "history", text: h.title, url: h.url, sub: h.url })),
  ];

  let remote = [];
  if (!looksLikeUrl(q)) {
    const results = await window.zaris.suggest(q);
    if (mySeq !== suggestSeq) return; // a newer keystroke has already superseded this fetch
    remote = results
      .filter((s) => s.toLowerCase() !== qLower)
      .slice(0, 5)
      .map((s) => ({ type: "search", text: s }));
  }
  if (mySeq !== suggestSeq) return;

  suggestionItems = [...local, ...remote];
  highlightedIndex = -1;
  renderSuggestions();
}

urlbar.addEventListener("input", () => {
  clearTimeout(suggestTimer);
  const value = urlbar.value;
  suggestTimer = setTimeout(() => updateSuggestions(value), 150);
});

window.addEventListener("click", (e) => {
  if (!e.target.closest(".urlbar-wrap")) closeSuggestions();
});

// ------------------------------------------------------------- controls --
urlbar.addEventListener("keydown", (e) => {
  if (e.key === "ArrowDown" && suggestionItems.length > 0) {
    e.preventDefault();
    highlightedIndex = Math.min(highlightedIndex + 1, suggestionItems.length - 1);
    renderSuggestions();
    return;
  }
  if (e.key === "ArrowUp" && suggestionItems.length > 0) {
    e.preventDefault();
    highlightedIndex = Math.max(highlightedIndex - 1, -1);
    renderSuggestions();
    return;
  }
  if (e.key === "Escape" && suggestionItems.length > 0) {
    closeSuggestions();
    return;
  }
  if (e.key === "Enter") {
    const t = currentTab();
    if (!t) return;
    if (highlightedIndex >= 0 && suggestionItems[highlightedIndex]) {
      pickSuggestion(suggestionItems[highlightedIndex]);
      return;
    }
    closeSuggestions();
    t.webview.loadURL(normalize(urlbar.value));
    t.webview.focus();
  }
});
urlbar.addEventListener("focus", () => urlbar.select());

btnBack.addEventListener("click", () => currentTab()?.webview.goBack());
btnFwd.addEventListener("click", () => currentTab()?.webview.goForward());
btnReload.addEventListener("click", () => currentTab()?.webview.reload());
btnHome.addEventListener("click", () => currentTab()?.webview.loadURL(START_URL));
btnNewtab.addEventListener("click", () => createTab(START_URL));

// ------------------------------------------------------------- titlebar --
const winMin = document.getElementById("win-min");
const winMax = document.getElementById("win-max");
const winClose = document.getElementById("win-close");

winMin.addEventListener("click", () => window.zaris.window.minimize());
winMax.addEventListener("click", () => window.zaris.window.maximize());
winClose.addEventListener("click", () => window.zaris.window.close());

function setMaximizedIcon(isMax) {
  winMax.innerHTML = isMax ? "&#10064;" : "&#9633;"; // restore glyph vs. plain square
  winMax.title = isMax ? "Restore" : "Maximize";
}
window.zaris.window.isMaximized().then(setMaximizedIcon);
window.zaris.window.onMaximizedChange(setMaximizedIcon);
document.getElementById("titlebar").addEventListener("dblclick", (e) => {
  if (e.target.id === "titlebar" || e.target.id === "app-name") window.zaris.window.maximize();
});

btnStar.addEventListener("click", async () => {
  const t = currentTab();
  if (!t || isInternalUrl(t.url)) return;
  const already = btnStar.classList.contains("active");
  if (already) {
    const all = await window.zaris.data.get();
    const match = all.bookmarks.find((b) => b.url === t.url);
    if (match) await window.zaris.data.removeBookmark(match.id);
  } else {
    await window.zaris.data.addBookmark(t.title, t.url);
  }
  btnStar.classList.toggle("active", !already);
  if (libraryPanel.classList.contains("visible")) renderBookmarks();
});

btnShield.addEventListener("click", () => {
  blockingEnabled = !blockingEnabled;
  btnShield.classList.toggle("blocking-off", !blockingEnabled);
  btnShield.title = blockingEnabled ? "Ad/tracker blocking: on" : "Ad/tracker blocking: off (reload tabs)";
  // Full runtime toggling of the session-level blocker is a main-process
  // concern; wire this up to an ipc call to main.js if you want the button
  // to flip actual filtering rather than just its own indicator.
});

// ----------------------------------------------------------- shortcuts ---
// Split from the actual key-listening so the exact same logic can run
// whether the key came from our own host window (focus on the address bar,
// a tab, a panel) or was forwarded from main.js after being caught via
// before-input-event inside a webview's content — see the comment on
// window.zaris.onGlobalShortcut below for why that second path exists.
function dispatchShortcut(e) {
  const mod = e.ctrlKey || e.metaKey;
  if (mod && e.key.toLowerCase() === "t" && e.shiftKey) { e.preventDefault(); reopenClosedTab(); return; }
  if (mod && e.key.toLowerCase() === "t") { e.preventDefault(); createTab(START_URL); }
  if (mod && e.key.toLowerCase() === "w") { e.preventDefault(); if (activeId !== null) closeTab(activeId); }
  if (mod && e.key.toLowerCase() === "l") { e.preventDefault(); urlbar.focus(); }
  if (mod && e.key.toLowerCase() === "r") { e.preventDefault(); currentTab()?.webview.reload(); }
  if (mod && !e.shiftKey && e.key.toLowerCase() === "f") { e.preventDefault(); openFindBar(); }
  if (mod && e.key.toLowerCase() === "d") { e.preventDefault(); btnStar.click(); }
  if (mod && e.key.toLowerCase() === "j") { e.preventDefault(); openLibrary("downloads"); }
  if (mod && e.key.toLowerCase() === "k") { e.preventDefault(); openCommandPalette(); }
  if (mod && e.shiftKey && e.key.toLowerCase() === "n") { e.preventDefault(); createTab(START_URL, { temporary: true }); }
  if (mod && e.shiftKey && e.key.toLowerCase() === "f") { e.preventDefault(); toggleFocusMode(); }
  if (mod && e.shiftKey && e.key.toLowerCase() === "s") { e.preventDefault(); takeScreenshot("visible"); }
  if (e.altKey && e.key === "ArrowLeft") { e.preventDefault(); currentTab()?.webview.goBack(); }
  if (e.altKey && e.key === "ArrowRight") { e.preventDefault(); currentTab()?.webview.goForward(); }
  if (e.altKey && e.key === "Home") { e.preventDefault(); currentTab()?.webview.loadURL(START_URL); }
  if (mod && e.key === "Tab") {
    e.preventDefault();
    if (tabs.length < 2) return;
    const idx = tabs.findIndex((t) => t.id === activeId);
    const next = tabs[(idx + 1) % tabs.length];
    activateTab(next.id);
  }
}

window.addEventListener("keydown", dispatchShortcut);

// Keys pressed while focus is inside a tab's actual page content never reach
// this window's own keydown listener at all — that content lives in a
// separate process. main.js catches the same combos earlier, at the
// before-input-event level (which sees every keystroke regardless of focus),
// and forwards them here so the exact same dispatchShortcut logic runs
// either way. Without this, every shortcut above would silently stop working
// the moment you clicked into a page — which is most of the time.
window.zaris.onGlobalShortcut((combo) => {
  dispatchShortcut({
    key: combo.key,
    ctrlKey: combo.ctrl,
    metaKey: combo.meta,
    shiftKey: combo.shift,
    altKey: combo.alt,
    preventDefault() {}, // already prevented on the main-process side
  });
});

// Links a page tries to pop open as a new OS window arrive here instead.
window.zaris.onOpenTab((url) => createTab(url));

// ---------------------------------------------------------- session restore
async function restoreSession() {
  let saved = null;
  try {
    saved = await window.zaris.session.get();
  } catch {
    // ignore — falls through to a fresh home tab below
  }

  if (!saved || !Array.isArray(saved.tabs) || saved.tabs.length === 0) {
    createTab(START_URL);
    return;
  }

  let toActivate = null;
  saved.tabs.forEach((entry, i) => {
    const url = entry.url === "zaris://home" ? START_URL : entry.url;
    const tab = createTab(url, { allowDuplicate: true });
    if (entry.pinned) togglePin(tab);
    if (i === saved.activeIndex) toActivate = tab;
  });
  // Reopened tabs don't carry over their own back/forward history — just
  // their last known URL — which is a smaller thing than losing the whole
  // session, but worth knowing if "back" feels like it starts from scratch.
  activateTab((toActivate || tabs[tabs.length - 1]).id);
}

restoreSession();

// ------------------------------------------------------- save my password?
const credBanner = document.createElement("div");
credBanner.id = "cred-banner";
credBanner.className = "hidden";
credBanner.innerHTML = `
  <span class="cred-text">Save this password?</span>
  <button class="cred-btn cred-save">Save</button>
  <button class="cred-btn cred-never">Never for this site</button>
  <button class="cred-btn cred-dismiss">Not now</button>`;
document.body.appendChild(credBanner);

let pendingCred = null;
window.zaris.creds.onOfferSave((data) => {
  pendingCred = data;
  credBanner.querySelector(".cred-text").textContent = `Save password for ${data.username} on ${data.hostname}?`;
  credBanner.classList.remove("hidden");
});
credBanner.querySelector(".cred-save").addEventListener("click", async () => {
  if (pendingCred) await window.zaris.creds.save(pendingCred.hostname, pendingCred.username, pendingCred.password);
  pendingCred = null;
  credBanner.classList.add("hidden");
});
credBanner.querySelector(".cred-never").addEventListener("click", () => {
  pendingCred = null;
  credBanner.classList.add("hidden");
});
credBanner.querySelector(".cred-dismiss").addEventListener("click", () => {
  pendingCred = null;
  credBanner.classList.add("hidden");
});

// Clean fade-in on launch rather than the window just snapping into view.
// Double rAF ensures the browser has committed the opacity:0 starting state
// before the transition to 1 is triggered, so it reliably animates.
requestAnimationFrame(() => requestAnimationFrame(() => document.body.classList.add("ready")));
