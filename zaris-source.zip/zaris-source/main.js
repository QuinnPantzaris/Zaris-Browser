const { app, BrowserWindow, session, ipcMain, shell, Menu, clipboard, safeStorage } = require("electron");
const path = require("path");
const fs = require("fs");

// EasyList/EasyPrivacy-grade blocking, same lists used in the qutebrowser build,
// so behavior stays consistent across both.
const { ElectronBlocker } = require("@ghostery/adblocker-electron");
const fetch = require("cross-fetch");

const SEARCH_URL = "https://search.brave.com/search?q=";

// ---------------------------------------------------------------------------
// Site-specific cosmetic cleanup. Runs entirely inside the page's own
// context via executeJavaScript — same idea as a userscript. Matched by
// hostname, so adding a new site is just another entry here.
//
// Brave Search's own header logo links out to brave.com (their browser's
// promo/download page) — since that's what makes it identifiable regardless
// of whatever class names their markup uses this month, that's what gets
// matched on, rather than a guess at a CSS selector that could break the
// next time Brave redesigns the page.
// ---------------------------------------------------------------------------
const SITE_QUIRKS = {
  "search.brave.com": `
    (function () {
      function hideBraveBranding() {
        document.querySelectorAll("a[href]").forEach((a) => {
          try {
            var url = new URL(a.href, location.href);
            if (url.hostname !== "brave.com" && url.hostname !== "www.brave.com") return;
            var rect = a.getBoundingClientRect();
            // Restrict to the top-left header area so an actual search
            // result that happens to link to brave.com never gets touched.
            if (rect.top < 140 && rect.left < 320) {
              a.style.setProperty("display", "none", "important");
              a.setAttribute("data-zaris-hidden", "brand-link");
            }
          } catch (_) {}
        });
      }
      hideBraveBranding();
      // Brave Search re-renders parts of its header between searches
      // without a full page reload — a MutationObserver keeps re-hiding it
      // rather than relying on this script only ever running once.
      if (!window.__zarisQuirkObserver) {
        window.__zarisQuirkObserver = new MutationObserver(hideBraveBranding);
        window.__zarisQuirkObserver.observe(document.documentElement, { childList: true, subtree: true });
      }
    })();
  `,
};

function applySiteQuirks(contents) {
  let url;
  try {
    url = new URL(contents.getURL());
  } catch {
    return;
  }
  const script = SITE_QUIRKS[url.hostname];
  if (script) contents.executeJavaScript(script).catch(() => {});
}

// ---------------------------------------------------------------------------
// Persistent data — bookmarks, history, downloads. Plain JSON on disk in the
// app's userData folder, so all of it survives closing and reopening Zaris.
// This file is small (a few thousand entries, worst case) and written
// infrequently enough that sync fs calls are fine — no need for a database.
// ---------------------------------------------------------------------------
const STORE_PATH = path.join(app.getPath("userData"), "zaris-data.json");
const MAX_HISTORY = 5000;

let store = { bookmarks: [], history: [], downloads: [], credentials: [], session: null, readingProgress: {}, notes: "", downloadRules: [] };

function loadStore() {
  try {
    const raw = fs.readFileSync(STORE_PATH, "utf-8");
    const parsed = JSON.parse(raw);
    store = {
      bookmarks: Array.isArray(parsed.bookmarks) ? parsed.bookmarks : [],
      history: Array.isArray(parsed.history) ? parsed.history : [],
      downloads: Array.isArray(parsed.downloads) ? parsed.downloads : [],
      credentials: Array.isArray(parsed.credentials) ? parsed.credentials : [],
      session: parsed.session && Array.isArray(parsed.session.tabs) ? parsed.session : null,
      readingProgress: parsed.readingProgress && typeof parsed.readingProgress === "object" ? parsed.readingProgress : {},
      notes: typeof parsed.notes === "string" ? parsed.notes : "",
      downloadRules: Array.isArray(parsed.downloadRules) ? parsed.downloadRules : [],
    };
  } catch (err) {
    // First run, or a corrupted/missing file — start clean rather than crash.
    store = { bookmarks: [], history: [], downloads: [], credentials: [], session: null, readingProgress: {}, notes: "", downloadRules: [] };
  }
}

let saveTimer = null;
function writeStoreNow() {
  try {
    fs.writeFileSync(STORE_PATH, JSON.stringify(store, null, 2), "utf-8");
  } catch (err) {
    console.warn("[zaris] failed to save data store:", err.message);
  }
}
function saveStore() {
  // Debounced: history entries in particular can arrive in quick bursts
  // (fast back-and-forth browsing), so batch writes instead of hitting disk
  // on every single one.
  clearTimeout(saveTimer);
  saveTimer = setTimeout(writeStoreNow, 300);
}
// Called on quit so a pending debounced write isn't lost if you close Zaris
// within that ~300ms window of your last tab/session change.
function flushStoreNow() {
  clearTimeout(saveTimer);
  writeStoreNow();
}

loadStore();

const APP_START_TS = Date.now();
let readyAtTs = null;

let mainWindow;

// Force-dark rendering for sites that don't ship their own dark theme. This is
// what actually fixes "the white killed my eyes" everywhere, not just on one
// search engine's results page. Some sites with unusual canvas/video-heavy
// UIs can render oddly under this — toggle it off per-tab if that happens.
app.commandLine.appendSwitch("force-dark-mode");
app.commandLine.appendSwitch("enable-features", "WebContentsForceDark,WebContentsForceDarkModeMode");

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 760,
    minHeight: 480,
    backgroundColor: "#0f0f0e",
    icon: path.join(__dirname, "assets", "icon.png"),
    frame: false, // no native title bar at all — our own #titlebar strip IS the top edge,
                  // so there's no seam/color-mismatch between OS chrome and app chrome
    show: false, // wait for first paint so you never see a blank/flashing frame
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
      webviewTag: true,
      sandbox: false, // needed so the preload can use contextBridge with webviewTag
    },
  });

  mainWindow.once("ready-to-show", () => {
    readyAtTs = Date.now();
    mainWindow.show();
  });
  mainWindow.loadFile("index.html");

  mainWindow.on("maximize", () => mainWindow.webContents.send("window:maximized", true));
  mainWindow.on("unmaximize", () => mainWindow.webContents.send("window:maximized", false));

  // Uncomment while developing the UI:
  // mainWindow.webContents.openDevTools({ mode: "detach" });
}

// Frameless means Windows/Linux no longer draw minimize/maximize/close for
// us — these back the custom buttons in the #titlebar strip instead.
ipcMain.on("window:minimize", () => mainWindow?.minimize());
ipcMain.on("window:maximize", () => {
  if (!mainWindow) return;
  mainWindow.isMaximized() ? mainWindow.unmaximize() : mainWindow.maximize();
});
ipcMain.on("window:close", () => mainWindow?.close());
ipcMain.handle("window:isMaximized", () => mainWindow?.isMaximized() ?? false);

// Any link a page tries to pop open as a real new OS window gets sent back to
// the renderer to open as a Zaris tab instead of spawning a bare Chromium window.
app.on("web-contents-created", (_event, contents) => {
  if (contents.getType() !== "webview") return;

  contents.on("dom-ready", () => applySiteQuirks(contents));
  contents.on("did-navigate-in-page", () => applySiteQuirks(contents));

  // Keys typed while focus is inside a tab's actual page content never reach
  // the host window's own keydown listener — that content is a separate
  // process. before-input-event sees every keystroke here regardless of
  // focus, so this is the only reliable way to make shortcuts work "100% of
  // the time" rather than only when focus happens to be on our own UI.
  // Deliberately narrow: only combos Zaris actually reserves get intercepted
  // (and prevented from also reaching the page) — everything else passes
  // through untouched so a site's own shortcuts (video player controls,
  // its own search-in-page, etc.) keep working normally.
  contents.on("before-input-event", (event, input) => {
    if (input.type !== "keyDown") return;
    const mod = input.control || input.meta;
    const key = input.key.toLowerCase();
    const reserved =
      (mod && !input.shift && ["t", "w", "l", "r", "f", "d", "j", "k"].includes(key)) ||
      (mod && input.shift && ["t", "n", "f", "s"].includes(key)) ||
      (mod && input.key === "Tab") ||
      (input.alt && ["arrowleft", "arrowright", "home"].includes(key));
    if (!reserved) return;
    event.preventDefault();
    mainWindow?.webContents.send("global-shortcut", {
      key: input.key,
      ctrl: input.control,
      meta: input.meta,
      shift: input.shift,
      alt: input.alt,
    });
  });

  contents.setWindowOpenHandler(({ url }) => {
    mainWindow.webContents.send("open-tab", url);
    return { action: "deny" };
  });

  // ---- right-click menu ---------------------------------------------------
  contents.on("context-menu", (_e, params) => {
    const items = [];

    if (params.linkURL) {
      items.push(
        { label: "Open Link in New Tab", click: () => mainWindow.webContents.send("open-tab", params.linkURL) },
        { label: "Copy Link Address", click: () => clipboard.writeText(params.linkURL) },
        { type: "separator" }
      );
    }

    if (params.hasImageContents) {
      items.push(
        { label: "Open Image in New Tab", click: () => mainWindow.webContents.send("open-tab", params.srcURL) },
        { label: "Save Image As\u2026", click: () => contents.downloadURL(params.srcURL) },
        { label: "Copy Image", click: () => contents.copyImageAt(params.x, params.y) },
        { label: "Copy Image Address", click: () => clipboard.writeText(params.srcURL) },
        { type: "separator" }
      );
    }

    if (params.selectionText) {
      const shortText = params.selectionText.length > 24
        ? params.selectionText.slice(0, 24) + "\u2026"
        : params.selectionText;
      items.push(
        { label: "Copy", role: "copy" },
        {
          label: `Search Brave for "${shortText}"`,
          click: () => mainWindow.webContents.send("open-tab", SEARCH_URL + encodeURIComponent(params.selectionText)),
        },
        { type: "separator" }
      );
    }

    if (params.isEditable) {
      if (params.misspelledWord) {
        if (params.dictionarySuggestions.length > 0) {
          for (const suggestion of params.dictionarySuggestions.slice(0, 5)) {
            items.push({ label: suggestion, click: () => contents.replaceMisspelling(suggestion) });
          }
        } else {
          items.push({ label: "No spelling suggestions", enabled: false });
        }
        items.push(
          { label: "Add to Dictionary", click: () => contents.session.addWordToSpellCheckerDictionary(params.misspelledWord) },
          { type: "separator" }
        );
      }
      items.push(
        { label: "Cut", role: "cut", enabled: params.editFlags.canCut },
        { label: "Copy", role: "copy", enabled: params.editFlags.canCopy },
        { label: "Paste", role: "paste", enabled: params.editFlags.canPaste },
        { label: "Select All", role: "selectAll" },
        { type: "separator" }
      );
    }

    items.push(
      { label: "Back", enabled: contents.canGoBack(), click: () => contents.goBack() },
      { label: "Forward", enabled: contents.canGoForward(), click: () => contents.goForward() },
      { label: "Reload", click: () => contents.reload() },
      { type: "separator" },
      { label: "Inspect Element", click: () => contents.inspectElement(params.x, params.y) }
    );

    Menu.buildFromTemplate(items).popup();
  });
});

ipcMain.handle("open-external", (_e, url) => shell.openExternal(url));

// ------------------------------------------------------- search suggest --
// This is the same endpoint Brave documents for other browsers to use for
// address-bar predictions when Brave Search is their engine — no API key,
// unlike the paid api.search.brave.com developer API.
ipcMain.handle("suggest", async (_e, query) => {
  const q = (query || "").trim();
  if (q.length < 2) return [];
  try {
    const res = await fetch(`https://search.brave.com/api/suggest?q=${encodeURIComponent(q)}`, {
      headers: { Accept: "application/json" },
    });
    const data = await res.json();
    // Classic OpenSearch suggestion shape: [query, [suggestion, suggestion, ...]].
    // Handled defensively in case Brave ever changes the response shape.
    let list = [];
    if (Array.isArray(data) && Array.isArray(data[1])) list = data[1];
    else if (Array.isArray(data)) list = data.filter((x) => typeof x === "string");
    return list.slice(0, 6);
  } catch (err) {
    return []; // offline, or the endpoint hiccuped — predictions just don't show up
  }
});

// ---------------------------------------------------------------- data ----
ipcMain.handle("data:get", () => store);

ipcMain.handle("data:addBookmark", (_e, { title, url }) => {
  if (store.bookmarks.some((b) => b.url === url)) return store.bookmarks; // no dupes
  store.bookmarks.unshift({ id: Date.now() + Math.random(), title: title || url, url, createdAt: Date.now() });
  saveStore();
  return store.bookmarks;
});

ipcMain.handle("data:removeBookmark", (_e, id) => {
  store.bookmarks = store.bookmarks.filter((b) => b.id !== id);
  saveStore();
  return store.bookmarks;
});

ipcMain.handle("data:isBookmarked", (_e, url) => store.bookmarks.some((b) => b.url === url));

ipcMain.handle("data:addHistory", (_e, { title, url }) => {
  // Collapse rapid repeat visits (reloads, redirects) into the existing entry
  // rather than spamming the list with the same page over and over.
  const recent = store.history[0];
  if (recent && recent.url === url && Date.now() - recent.visitedAt < 5000) {
    recent.visitedAt = Date.now();
    recent.title = title || recent.title;
  } else {
    store.history.unshift({ id: Date.now() + Math.random(), title: title || url, url, visitedAt: Date.now() });
    if (store.history.length > MAX_HISTORY) store.history.length = MAX_HISTORY;
  }
  saveStore();
  return true;
});

ipcMain.handle("data:removeHistoryEntry", (_e, id) => {
  store.history = store.history.filter((h) => h.id !== id);
  saveStore();
  return store.history;
});

ipcMain.handle("data:clearHistory", () => {
  store.history = [];
  saveStore();
  return store.history;
});

ipcMain.handle("data:clearDownloads", () => {
  store.downloads = store.downloads.filter((d) => d.state === "progressing");
  saveStore();
  return store.downloads;
});

ipcMain.handle("data:showItemInFolder", (_e, filePath) => shell.showItemInFolder(filePath));
ipcMain.handle("data:openPath", (_e, filePath) => shell.openPath(filePath));

// --------------------------------------------------------- session ------
ipcMain.handle("session:get", () => store.session);
ipcMain.handle("session:save", (_e, sessionData) => {
  store.session = sessionData;
  saveStore();
  return true;
});

// ------------------------------------------------------- credentials ----
// Passwords are encrypted at rest with the OS's own credential store —
// Windows DPAPI, macOS Keychain, or libsecret on Linux — via Electron's
// safeStorage, rather than sitting in the JSON file as plain text. Note
// what this does and doesn't protect against: it protects the file on
// disk from casual reading; it does not protect against something with
// full run-as-you access to your unlocked Windows account, since that's
// the same trust boundary the OS itself uses to decrypt it.
function encryptionAvailable() {
  return safeStorage.isEncryptionAvailable();
}

ipcMain.handle("creds:forHost", (_e, hostname) => {
  if (!encryptionAvailable()) return [];
  return store.credentials
    .filter((c) => c.hostname === hostname)
    .map((c) => {
      try {
        return { id: c.id, username: c.username, password: safeStorage.decryptString(Buffer.from(c.password, "base64")) };
      } catch {
        return null; // encrypted with a since-changed OS key (rare) — skip rather than crash
      }
    })
    .filter(Boolean);
});

ipcMain.handle("creds:save", (_e, { hostname, username, password }) => {
  if (!encryptionAvailable()) return false;
  const encrypted = safeStorage.encryptString(password).toString("base64");
  const existing = store.credentials.find((c) => c.hostname === hostname && c.username === username);
  if (existing) {
    existing.password = encrypted;
    existing.updatedAt = Date.now();
  } else {
    store.credentials.push({ id: Date.now() + Math.random(), hostname, username, password: encrypted, createdAt: Date.now() });
  }
  saveStore();
  return true;
});

ipcMain.handle("creds:list", () =>
  store.credentials.map((c) => ({ id: c.id, hostname: c.hostname, username: c.username, createdAt: c.createdAt }))
);

ipcMain.handle("creds:remove", (_e, id) => {
  store.credentials = store.credentials.filter((c) => c.id !== id);
  saveStore();
  return true;
});

// A webview's own preload script (webview-preload.js) detects login-form
// submissions and reports them here; relayed to the host UI so it can show
// a "Save this password?" prompt, styled like the rest of Zaris rather than
// a native OS dialog.
ipcMain.on("creds:submitted", (_e, data) => {
  if (mainWindow) mainWindow.webContents.send("creds:offer-save", data);
});

// ------------------------------------------------------------ downloads ---
function pushDownloadUpdate(record) {
  if (mainWindow) mainWindow.webContents.send("download-update", record);
}

const activeDownloadItems = new Map(); // record.id -> live DownloadItem (can't be persisted/serialized)
const MAX_CONCURRENT_DOWNLOADS = 2;
let pendingQueue = []; // record ids waiting for a concurrency slot, in start order

function sanitizeFilename(name) {
  return name.replace(/[\\/:*?"<>|]+/g, "_").trim().slice(0, 150) || "file";
}

// Chromium's suggested filename is usually fine, but falls back to generic
// names like "download.pdf" or "download (6).pdf" when a site doesn't supply
// a real one — using the source page's own title instead is normally a much
// more useful name to find later.
function chooseSavePath(item, initiatingContents) {
  const url = item.getURL();
  let hostname = "";
  try {
    hostname = new URL(url).hostname;
  } catch {
    /* relative/blob URLs etc. — hostname stays blank, folder rules just won't match */
  }

  const suggested = item.getFilename();
  const genericPattern = /^(download|file|untitled)(\s*\(\d+\))?\.[a-z0-9]+$/i;
  let filename = suggested;
  if (genericPattern.test(suggested) && initiatingContents && !initiatingContents.isDestroyed()) {
    const pageTitle = initiatingContents.getTitle();
    if (pageTitle && pageTitle.trim()) {
      const ext = path.extname(suggested) || "";
      filename = sanitizeFilename(pageTitle) + ext;
    }
  }

  const rule = store.downloadRules.find((r) => r.match && (hostname.includes(r.match) || url.includes(r.match)));
  const baseDir = app.getPath("downloads");
  const dir = rule ? path.join(baseDir, rule.folder) : baseDir;
  try {
    fs.mkdirSync(dir, { recursive: true });
  } catch {
    /* if this fails, setSavePath below will just fail over to Chromium's own default prompt/location */
  }

  const ext = path.extname(filename);
  const base = path.basename(filename, ext);
  let finalPath = path.join(dir, filename);
  let counter = 1;
  while (fs.existsSync(finalPath)) {
    finalPath = path.join(dir, `${base} (${counter})${ext}`);
    counter++;
  }
  return finalPath;
}

function startNextQueued() {
  const nextId = pendingQueue.shift();
  if (nextId == null) return;
  const item = activeDownloadItems.get(nextId);
  const record = store.downloads.find((d) => d.id === nextId);
  if (item && record) {
    record.queued = false;
    record.paused = false;
    item.resume();
    pushDownloadUpdate(record);
  } else {
    startNextQueued(); // that one's gone (cancelled/closed) — try the next
  }
}

app.whenReady().then(() => {
  session.defaultSession.on("will-download", (_event, item, initiatingContents) => {
    const id = Date.now() + Math.random();
    item.setSavePath(chooseSavePath(item, initiatingContents));

    const record = {
      id,
      filename: path.basename(item.getSavePath()),
      url: item.getURL(),
      savePath: item.getSavePath(),
      state: "progressing",
      receivedBytes: 0,
      totalBytes: item.getTotalBytes(),
      startedAt: Date.now(),
      paused: false,
      queued: false,
    };

    activeDownloadItems.set(id, item);

    const runningCount = store.downloads.filter((d) => d.state === "progressing" && !d.queued).length;
    if (runningCount >= MAX_CONCURRENT_DOWNLOADS) {
      record.queued = true;
      record.paused = true;
      pendingQueue.push(id);
      item.pause();
    }

    store.downloads.unshift(record);
    saveStore();
    pushDownloadUpdate(record);

    item.on("updated", (_e, state) => {
      record.state = state;
      record.receivedBytes = item.getReceivedBytes();
      record.savePath = item.getSavePath();
      record.paused = item.isPaused();
      pushDownloadUpdate(record);
    });

    item.once("done", (_e, state) => {
      record.state = state; // "completed" | "cancelled" | "interrupted"
      record.receivedBytes = item.getReceivedBytes();
      record.savePath = item.getSavePath();
      record.queued = false;
      activeDownloadItems.delete(id);
      pendingQueue = pendingQueue.filter((qid) => qid !== id);
      saveStore();
      pushDownloadUpdate(record);
      startNextQueued();
    });
  });
});

ipcMain.handle("downloads:pause", (_e, id) => {
  const item = activeDownloadItems.get(id);
  if (item && !item.isPaused()) item.pause();
  const record = store.downloads.find((d) => d.id === id);
  if (record) {
    record.paused = true;
    pushDownloadUpdate(record);
  }
  return true;
});

ipcMain.handle("downloads:resume", (_e, id) => {
  const item = activeDownloadItems.get(id);
  const record = store.downloads.find((d) => d.id === id);
  if (record && record.queued) return true; // stays paused until its turn in the queue comes up
  if (item && item.isPaused()) item.resume();
  if (record) {
    record.paused = false;
    pushDownloadUpdate(record);
  }
  return true;
});

ipcMain.handle("downloads:cancel", (_e, id) => {
  const item = activeDownloadItems.get(id);
  if (item) item.cancel();
  pendingQueue = pendingQueue.filter((qid) => qid !== id);
  return true;
});

ipcMain.handle("downloads:reorder", (_e, id, direction) => {
  const idx = pendingQueue.indexOf(id);
  if (idx === -1) return false;
  const swapWith = direction === "up" ? idx - 1 : idx + 1;
  if (swapWith < 0 || swapWith >= pendingQueue.length) return false;
  [pendingQueue[idx], pendingQueue[swapWith]] = [pendingQueue[swapWith], pendingQueue[idx]];
  return true;
});

// -------------------------------------------------- download folder rules -
ipcMain.handle("downloadRules:list", () => store.downloadRules);
ipcMain.handle("downloadRules:add", (_e, { match, folder }) => {
  if (!match || !folder) return store.downloadRules;
  store.downloadRules.push({ id: Date.now() + Math.random(), match: match.trim(), folder: folder.trim() });
  saveStore();
  return store.downloadRules;
});
ipcMain.handle("downloadRules:remove", (_e, id) => {
  store.downloadRules = store.downloadRules.filter((r) => r.id !== id);
  saveStore();
  return store.downloadRules;
});

// ---------------------------------------------------------- reading progress
// Keyed by URL. Pruned on load if it grows past a few thousand entries so it
// doesn't grow forever for a heavy browsing habit.
ipcMain.handle("reading:get", (_e, url) => store.readingProgress[url] || null);
ipcMain.handle("reading:save", (_e, { url, scrollY, scrollHeight }) => {
  store.readingProgress[url] = { scrollY, scrollHeight, updatedAt: Date.now() };
  const keys = Object.keys(store.readingProgress);
  if (keys.length > 3000) {
    keys
      .sort((a, b) => store.readingProgress[a].updatedAt - store.readingProgress[b].updatedAt)
      .slice(0, keys.length - 3000)
      .forEach((k) => delete store.readingProgress[k]);
  }
  saveStore();
  return true;
});

// --------------------------------------------------------------- notes ---
// One persistent scratchpad, not a multi-document system — deliberately
// simple, per the "opens instantly, simple text only" brief.
ipcMain.handle("notes:get", () => store.notes);
ipcMain.handle("notes:save", (_e, text) => {
  store.notes = typeof text === "string" ? text : "";
  saveStore();
  return true;
});

// ---------------------------------------------------------- health metrics
ipcMain.handle("health:get", async () => {
  const metrics = app.getAppMetrics();
  const totalMemoryKB = metrics.reduce((sum, m) => sum + (m.memory?.workingSetSize || 0), 0);
  const cacheSize = await session.defaultSession.getCacheSize().catch(() => 0);
  const dupeUrlCounts = {};
  for (const b of store.bookmarks) dupeUrlCounts[b.url] = (dupeUrlCounts[b.url] || 0) + 1;
  const duplicateBookmarks = Object.values(dupeUrlCounts).filter((n) => n > 1).length;

  return {
    startupMs: readyAtTs ? readyAtTs - APP_START_TS : null,
    memoryMB: Math.round(totalMemoryKB / 1024),
    processCount: metrics.length,
    cacheMB: Math.round(cacheSize / (1024 * 1024)),
    duplicateBookmarks,
    historyCount: store.history.length,
    bookmarkCount: store.bookmarks.length,
  };
});

ipcMain.handle("health:clearCache", async () => {
  await session.defaultSession.clearCache();
  return true;
});

// ------------------------------------------------------------ screenshots
ipcMain.handle("screenshot:save", async (_e, dataUrl) => {
  const dir = path.join(app.getPath("pictures"), "Zaris Screenshots");
  try {
    fs.mkdirSync(dir, { recursive: true });
  } catch {
    return { ok: false };
  }
  const filename = `Zaris-${new Date().toISOString().replace(/[:.]/g, "-")}.png`;
  const filePath = path.join(dir, filename);
  const base64 = dataUrl.replace(/^data:image\/png;base64,/, "");
  try {
    fs.writeFileSync(filePath, Buffer.from(base64, "base64"));
    return { ok: true, path: filePath };
  } catch (err) {
    return { ok: false, error: err.message };
  }
});

app.whenReady().then(() => {
  // Chromium's built-in spellchecker — underlines misspelled words in any
  // editable field on any page, and feeds suggestions into the right-click
  // menu (wired up below in the context-menu handler).
  session.defaultSession.setSpellCheckerEnabled(true);
  try {
    session.defaultSession.setSpellCheckerLanguages(["en-US"]);
  } catch (err) {
    console.warn("[zaris] spellchecker language setup failed:", err.message);
  }

  // EasyList/EasyPrivacy alone are general-purpose network-request blockers —
  // they catch most ad/tracker requests across the web, but YouTube serves
  // its ads through the same first-party pipeline as the actual video, so a
  // request-blocking-only list can't tell them apart. Blocking those
  // specifically needs uBlock Origin's own extended-syntax filters (cosmetic
  // + scriptlet rules targeting YouTube's player internals directly, not
  // just its network requests) — "quick-fixes" in particular is uBlock's
  // fast-turnaround list for exactly this kind of ongoing cat-and-mouse
  // countermeasure, refreshed every few hours upstream. Note that Zaris only
  // fetches lists once per launch, so a mid-session change on YouTube's end
  // won't be caught until the next restart — a real limitation of the
  // "fetch once at startup" approach versus a real extension's background
  // auto-updater.
  ElectronBlocker.fromLists(fetch, [
    "https://easylist.to/easylist/easylist.txt",
    "https://easylist.to/easylist/easyprivacy.txt",
    "https://easylist-downloads.adblockplus.org/easylistdutch.txt",
    "https://www.i-dont-care-about-cookies.eu/abp/",
    "https://raw.githubusercontent.com/uBlockOrigin/uAssets/master/filters/filters.txt",
    "https://raw.githubusercontent.com/uBlockOrigin/uAssets/master/filters/quick-fixes.txt",
    "https://raw.githubusercontent.com/uBlockOrigin/uAssets/master/filters/unbreak.txt",
  ])
    .then((blocker) => {
      blocker.enableBlockingInSession(session.defaultSession);
      console.log(`[zaris] adblock ready — ${blocker.numberOfNetworkFilters} network filters loaded`);
    })
    .catch((err) => {
      // No internet on first launch, or the lists were unreachable — Zaris
      // still works fine, it just isn't filtering anything until this succeeds.
      console.warn("[zaris] adblock lists failed to load, continuing without them:", err.message);
    });

  createWindow();

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});

app.on("before-quit", () => flushStoreNow());
