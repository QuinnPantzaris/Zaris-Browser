// This preload runs inside every page Zaris loads in a tab — same idea as a
// BrowserWindow's preload, but for the guest page inside a <webview>. It has
// Node/ipcRenderer access here, before the page's own scripts run, but
// nothing is exposed to the page itself (no contextBridge calls), so a site
// can't detect or interfere with any of this.
const { ipcRenderer } = require("electron");

function findLoginFields(root) {
  const passwordField = root.querySelector('input[type="password"]');
  if (!passwordField) return null;
  const form = passwordField.closest("form") || root;
  const usernameField =
    form.querySelector('input[type="email"]') ||
    form.querySelector('input[type="text"]') ||
    form.querySelector('input[autocomplete="username"]');
  return { form, usernameField, passwordField };
}

// ---- autofill: on load, fill in a saved credential if exactly one exists --
async function tryAutofill() {
  const fields = findLoginFields(document);
  if (!fields || !fields.usernameField) return;

  let creds;
  try {
    creds = await ipcRenderer.invoke("creds:forHost", location.hostname);
  } catch {
    return;
  }
  if (!creds || creds.length !== 1) return; // ambiguous with 2+ saved logins — let the person pick manually
  if (fields.usernameField.value || fields.passwordField.value) return; // don't clobber something already typed

  const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value").set;
  nativeSetter.call(fields.usernameField, creds[0].username);
  nativeSetter.call(fields.passwordField, creds[0].password);
  // Fire real input events so the page's own JS (React/Vue-controlled fields,
  // validation, submit-button enabling) notices the values changed.
  for (const el of [fields.usernameField, fields.passwordField]) {
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }
}

window.addEventListener("DOMContentLoaded", () => {
  tryAutofill();

  // ---- capture: report a login submission so the host can offer to save --
  document.addEventListener(
    "submit",
    (e) => {
      const fields = findLoginFields(e.target instanceof HTMLElement ? e.target : document);
      if (!fields || !fields.usernameField || !fields.passwordField.value) return;
      ipcRenderer.send("creds:submitted", {
        hostname: location.hostname,
        username: fields.usernameField.value,
        password: fields.passwordField.value,
      });
    },
    { capture: true }
  );
});
