// This preload runs inside every page Zaris loads in a tab — same idea as a
// BrowserWindow's preload, but for the guest page inside a <webview>. It has
// Node/ipcRenderer access here, before the page's own scripts run, but
// nothing is exposed to the page itself (no contextBridge calls), so a site
// can't detect or interfere with any of this.
const { ipcRenderer, contextBridge } = require("electron");

// ------------------------------------------------- reading progress ------
// Remembers scroll position per-URL so reopening a long article/doc picks up
// roughly where you left off. Skipped for our own internal file:// pages —
// there's no "reading progress" on a search bar.
const READING_PROGRESS_ELIGIBLE = location.protocol === "http:" || location.protocol === "https:";

function saveScrollPosition() {
  if (!READING_PROGRESS_ELIGIBLE) return;
  ipcRenderer.invoke("reading:save", {
    url: location.href,
    scrollY: window.scrollY,
    scrollHeight: document.documentElement.scrollHeight,
  });
}

let scrollSaveTimer = null;
function scheduleScrollSave() {
  clearTimeout(scrollSaveTimer);
  scrollSaveTimer = setTimeout(saveScrollPosition, 600);
}

async function restoreScrollPosition() {
  if (!READING_PROGRESS_ELIGIBLE) return;
  try {
    const saved = await ipcRenderer.invoke("reading:get", location.href);
    // Only worth restoring if you'd scrolled a meaningful amount, and the
    // page is roughly the same length as it was (hasn't been rewritten).
    if (saved && saved.scrollY > 200) {
      requestAnimationFrame(() => window.scrollTo({ top: saved.scrollY, behavior: "instant" }));
    }
  } catch {
    /* no saved position, or the call failed — just start at the top like normal */
  }
}

window.addEventListener("scroll", scheduleScrollSave, { passive: true });
window.addEventListener("beforeunload", saveScrollPosition);
window.addEventListener("DOMContentLoaded", restoreScrollPosition);

// ---------------------------------------------- internal-page bridge -----
// file:// pages can only ever be Zaris's own bundled HTML (startpage, error,
// notes) — a remote site can never navigate itself to file://, so exposing
// a small privileged API here is safe specifically because of that
// browser-level restriction, not something this code has to enforce itself.
if (location.protocol === "file:" && location.pathname.endsWith("/notes.html")) {
  contextBridge.exposeInMainWorld("zarisNotes", {
    get: () => ipcRenderer.invoke("notes:get"),
    save: (text) => ipcRenderer.invoke("notes:save", text),
  });
}

function findLoginFields(root) {
  const passwordField = root.querySelector('input[type="password"]');
  if (!passwordField) return null;
  const form = passwordField.closest("form") || root;
  const usernameField =
    form.querySelector('input[type="email"]') ||
    form.querySelector('input[type="text"]') ||
    form.querySelector('input[autocomplete="username"]');
  return { form, usernameField, passwordField };
}

// ---- autofill: on load, fill in a saved credential if exactly one exists --
async function tryAutofill() {
  const fields = findLoginFields(document);
  if (!fields || !fields.usernameField) return;

  let creds;
  try {
    creds = await ipcRenderer.invoke("creds:forHost", location.hostname);
  } catch {
    return;
  }
  if (!creds || creds.length !== 1) return; // ambiguous with 2+ saved logins — let the person pick manually
  if (fields.usernameField.value || fields.passwordField.value) return; // don't clobber something already typed

  const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value").set;
  nativeSetter.call(fields.usernameField, creds[0].username);
  nativeSetter.call(fields.passwordField, creds[0].password);
  // Fire real input events so the page's own JS (React/Vue-controlled fields,
  // validation, submit-button enabling) notices the values changed.
  for (const el of [fields.usernameField, fields.passwordField]) {
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }
}

window.addEventListener("DOMContentLoaded", () => {
  tryAutofill();

  // ---- capture: report a login submission so the host can offer to save --
  document.addEventListener(
    "submit",
    (e) => {
      const fields = findLoginFields(e.target instanceof HTMLElement ? e.target : document);
      if (!fields || !fields.usernameField || !fields.passwordField.value) return;
      ipcRenderer.send("creds:submitted", {
        hostname: location.hostname,
        username: fields.usernameField.value,
        password: fields.passwordField.value,
      });
    },
    { capture: true }
  );
});
